#include "prg_def.h"
#include "math.h"

void title(){
	printf("##########################################\n");
	printf("####             Vitalijs  Hodiko     ####\n");
	printf("####             RDBF05 091REB325     ####\n");
	printf("##########################################\n");
	printf("####  1 lab.d. Sazarotie procesi      ####\n");
	printf("####   *Lietotajs ievada x vertibu    ####\n");
	printf("####   *Atrast f vertibu              ####\n");
	printf("####   *Izvadit uz ekranu:            ####\n");
	printf("####    *x,a,b,y,                     ####\n");
	printf("####    *aprekinam izmantotajs zars   ####\n");
	printf("####   *Nekorektas ievades gadijuma   ####\n");
	printf("####     izvadit pazinojumu           ####\n");
	printf("##########################################\n");

	printf("#### f1=(3*a*a*b+a*a/b-3*b/a)/b^4,    ####\n");
	printf("####    ja b<=10                      ####\n");
	printf("#### f2=2*b*tan(a/2)/(a*sqrt(b*b-a*a))####\n");
	printf("#### a=(x+1/(x-1))^x-18*x             ####\n");
	printf("#### b=(x*x-7*x+10)/(x*x-8*x+12)      ####\n");
	printf("##########################################\n\n");
	}
	
	float f1(float a,float b){
	float res;
	res=(3*a*a*b+a*a/b-3*b/a)/pow(b,4);
	printf("#### f1=%4.2f\n",res);
	return res;
	}
	
float f2(float a,float b){
	float res;
	res=2*b*tan(a/2)/(a*sqrt(b*b-a*a));
	printf("#### f2=%4.2f\n",res);
	return res;
	}

void uzd(){
	float x,y,a,b;
	
	//spellcheck
	do{
	  cin.clear();
	  cin.sync();
	  printf("Please, enter x value[only numbers]:\nx=");
	  cin>>x;
	  if(cin.fail()) printf("An error occured. Please, try again!\n");
    }while(cin.fail());
    
    a=pow((x+1)/(x-1),x)-18*x;
    b=(x*x-7*x+10)/(x*x-8*x+12);
    
    if(((x-1)==0)||((x*x-8*x+12)==0)||(a==0)||(b==0)||(b==a))printf("\nBe aware. With %4.2f result  will be unexpected!\n",x);
    	
    printf("####RESULTS#################################\n");  
    printf("#### x=%4.2f\n",x);
	printf("#### a=%4.2f\n",a);	
	printf("#### b=%4.2f\n",b);
	  
	if(b<=10) y=f1(a,b);
	else      y=f2(a,b);

	printf("#### y=%4.2f\n",y);
	printf("############################################\n\n");
}
