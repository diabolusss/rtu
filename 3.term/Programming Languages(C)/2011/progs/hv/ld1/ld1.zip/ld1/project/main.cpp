/*     ld1.cpp rdbfo5 Vitalijs Hodiko
 *  1 labolatorijas darbs #Sazarotie procesi#
 *  Lietotajs ievada x vertibu. Atrast f vertibu. Izvadit uz ekranu: x,
 *  a,b,y, aprekinam izmantotajs zars. Nekorektas ievades gadijuma
 *  izvadit pazinojumu.
 */
/*  	f1=(3*a*a*b+a*a/b-3*b/a)/b^4 , ja b<=10
 *  	f2=2*b*tan(a/2)/(a*sqrt(b*b-a*a))
 *  	a=(x+1/(x-1))^x-18*x
 * 		b=(x*x-7*x+10)/(x*x-8*x+12)
 */

#include "prg_def.h"

int main(){
	int choice,x;
	bool ok;
	
	while(choice!=3){
		printf("####Menu####################################\n");
		printf("####1#Informacija par autoru un uzdevumu####\n");
		printf("####2#Uzdevuma izpilde                  ####\n");
		printf("####3#EXIT                              ####\n");
		printf("############################################\n");
		
        //spellcheck
		do{
			cin.clear(); //clears the error flag on cin
			cin.sync();  //the unread characters in the buffer are discarded.
			printf("Please, enter only numbers:\nMENU: ");
			cin>>choice;
			if(cin.fail()) printf("An error occured. Please, try again!\n");
		}while(cin.fail()); //returns true if either the failbit or the badbit is set

		switch(choice){
			case 1:title();
					break;
			case 2:uzd();
					break;
			case 3:return 0;
					break;
			
		}
		
	}	
}
