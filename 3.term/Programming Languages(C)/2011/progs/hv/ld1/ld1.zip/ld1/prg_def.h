#ifndef PRG_DEF_H
#define PRG_DEF_H

#include "stdio.h"

#define true 0
#define false 1

//function prototipes

void title();
float spellCheck(char *msg);
void uzd();

#endif
