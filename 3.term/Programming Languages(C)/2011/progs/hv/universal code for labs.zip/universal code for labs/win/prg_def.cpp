#include "prg_def.h"
#include "math.h"

void title(){
	printf("##########################################\n");
	printf("####             Vitalijs  Hodiko     ####\n");
	printf("####             RDBF05 091REB325     ####\n");
	printf("####                                  ####\n");
	printf("##########################################\n");
	printf("####  ####\n");
	printf("##########################################\n\n");
	}
	
float spellCheck(char *msg){
	 int ok,check;
	 float num;
	 
	 do {
        ok=false; 
        _flushall(); 
        printf("%s",msg);
        
     	try {
          	check=scanf("%f",&num);
          	throw(check);}  
        catch(int code){
          		  if (code==0) printf("Only digits and '.' is allowed!!! Please, try again.\n");
				  else ok=true;}
    	} while(ok!=true);

 	return num;
}

void uzd(){

}
