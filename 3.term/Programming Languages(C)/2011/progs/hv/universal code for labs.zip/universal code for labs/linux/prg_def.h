#ifndef PRG_DEF_H
#define PRG_DEF_H

#include "stdio.h"
#include <iostream>
using namespace std;

//function prototipes

void title();
void uzd();

#endif
