#include "prg_def.h"

int main(){
	int choice;
	while(choice!=3){
		printf("####Menu####################################\n");
		printf("####1#Informacija par autoru un uzdevumu####\n");
		printf("####2#Uzdevuma izpilde                  ####\n");
		printf("####3#EXIT                              ####\n");
		printf("############################################\n");
		
		do{
			cin.clear();
			cin.sync();
			printf("Please, enter only numbers:\nMENU: ");
			cin>>choice;
			if(cin.fail()) printf("An error occured. Please, try again!\n");
		}while(cin.fail());
		
		switch(choice){
			case 1:title();
					break;
			case 2:uzd();
					break;
			case 3:return 0;
					break;
			
		}
		
	}	
}
