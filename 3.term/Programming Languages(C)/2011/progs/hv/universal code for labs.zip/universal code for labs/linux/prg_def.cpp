#include "prg_def.h"

void title(){
	printf("##########################################\n");
	printf("####             Vitalijs  Hodiko     ####\n");
	printf("####             RDBF05 091REB325     ####\n");
	printf("##########################################\n");
	printf("####  1 lab.d. Sazarotie procesi      ####\n");
	printf("####   *Lietotajs ievada x vertibu    ####\n");
	printf("####   *Atrast f vertibu              ####\n");
	printf("####   *Izvadit uz ekranu:            ####\n");
	printf("####    *x,a,b,y,                     ####\n");
	printf("####    *aprekinam izmantotajs zars   ####\n");
	printf("####   *Nekorektas ievades gadijuma   ####\n");
	printf("####     izvadit pazinojumu           ####\n");
	printf("##########################################\n");

	printf("#### f1=(3*a*a*b+a*a/b-3*b/a)/b^4,    ####\n");
	printf("####    ja b<=10                      ####\n");
	printf("#### f2=2*b*tan(a/2)/(a*sqrt(b*b-a*a))####\n");
	printf("#### a=(x+1/(x-1))^x-18*x             ####\n");
	printf("#### b=(x*x-7*x+10)/(x*x-8*x+12)      ####\n");
	printf("##########################################\n");
	}

void uzd(){
	}
