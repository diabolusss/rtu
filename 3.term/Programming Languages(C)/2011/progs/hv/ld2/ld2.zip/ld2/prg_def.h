#ifndef PRG_DEF_H
	#define PRG_DEF_H 1

	#include <stdio.h>
	#include <stdlib.h>

	#define true 0
	#define false 1

	//win	system("cls");	//unix system("clear");
	
	#ifdef __unix__
		#define CLS system("clear");
	#elif defined _WIN32 // _WIN32 is defined by most compilers available for the Windows operating system (but not by all).
		#define CLS system("cls");
	#else
		#error "What's your operating system?"
	#endif

	//function prototipes
	void title();
	float spellCheck(char *msg);
	void uzd();
	void delay();

#endif
