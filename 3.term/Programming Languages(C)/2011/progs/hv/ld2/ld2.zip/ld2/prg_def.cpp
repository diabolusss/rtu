#include "prg_def.h"
#include <time.h>



void title(){
	printf("##########################################\n");
	printf("####             Vitalijs  Hodiko     ####\n");
	printf("####             RDBF05 091REB325     ####\n");
	printf("####                                  ####\n");
	printf("##########################################\n");
	printf("####      2ld 'masivu apstrade'       ####\n");
	printf("####                                  ####\n");
	printf("#### -Programmai jasastav:            ####\n");
	printf("####  *galvenas funkcijas             ####\n");
	printf("####   -info izvade par:              ####\n");
	printf("####    #autoru                       ####\n");
	printf("####    #masivu aizpildi[ar gadijuma  ####\n");
	printf("####      skaitliem vai patstavigi    ####\n");
	printf("####      ievaditi elementi]          ####\n");
	printf("####    #masiva izvadi                ####\n");
	printf("####    #apaksprogrammu izsaukumus    ####\n");
	printf("####                                  ####\n");
	printf("####  *divam apaksfunkcijam, kas      ####\n");
	printf("####    -veic the same masiva apstradi####\n");
	printf("####    -vienu realize ar mainigiem   ####\n");
	printf("####    -citu ar raditajiem           ####\n");
	printf("####                                  ####\n");
	printf("####  *fun-jam janodod:               ####\n");
	printf("####   -masivu[lokalais mainigais]    ####\n");
	printf("####   -ta indeksu augsejas robezas   ####\n");
	printf("####                                  ####\n");
	printf("#### -Programmas parbaudei izmantot   ####\n");
	printf("####   abus masivu izmerus            ####\n");
	printf("##########################################\n");
	printf("#### Individualais uzdevums           ####\n");
	printf("#### -Parveidot viendimensijas masivu ####\n");
	printf("####   ta, lai  katrs  elements  butu ####\n");
	printf("####   vienads  ar   starpibu   starp ####\n");
	printf("####   elementu  summu  un atbilstoso ####\n");
	printf("####   sakummasiva elementu.          ####\n");
	printf("####                                  ####\n");
	printf("##########################################\n\n");
	}
	
float spellCheck(char *msg){
	 int ok,check;
	 float num;
	 
	 do {
        ok=false; num=0;
        _flushall(); 		
		
        printf("%s",msg);
        
     	try {
          	check=scanf("%f",&num);
          	throw(check);}  
        catch(int code){
          		  if (code==0) {
					  printf("Only digits and '.' is allowed!!! Please, try again.\n");
					  //eats chars in input stream| for linux |
					  //scanf("%*c");
                      }
				  else ok=true;}
    	} while(ok!=true);

 	return num;
}

void delay(){
     int ok;
	do{ 
	_flushall();
	 
		ok=false;
		char answer;

		printf("Press any key...\n\n");
		scanf("%c",&answer);
	}while(not ok);
}

//summa lieto mainigos
int sum1(int mas[],int size){
	int res=0;
	for(int i=0;i<size;i++) res+=mas[i];
return res;
}

//summa lieto raditajus
int sum2(int mas[],int size){
	int res=0;
	for(int i=0;i<size;i++) res+=*(mas+i);
return res;
}

//f1 lieto mainigos
int f1(int mas[],int size,int sum){
	
	printf("Izsaukta 1 f-ja kas lieto mainigos ar indeksiem\n");
	for(int i=0;i<size;i++) mas[i]=sum-mas[i];
	
	//for(int i=0;i<size;i++) printf("mas[%d]=%d\n",i,mas[i]);
return 0;
}

//f2 lieto raditajus
int f2(int mas[],int size,int sum){

	printf("Izsaukta 2 f-ja kas lieto raditajus\n");
	for(int i=0;i<size;i++) *(mas+i)=sum-*(mas+i);
	
	//for(int i=0;i<size;i++) printf("mas[%d]=%d\n",i,*(mas+i));
return 0;
}

void uzd(){
	CLS;
	
    int n,ok;
	// /*
	do{
		int ans;
		ok=true;
		
		printf("Kuru masiva izmeru izmantot?\n 1) arr[15]\n 2) arr[25]\n");
		ans=(int)spellCheck("Choice: ");

		if (ans==1) n=15;
		else if (ans==2) n=25;
		else ok=false;
		
	}while(ok!=true);
	//*/
	//n=15;
	
	int arr[n];
	char ans;
	// /*
	do{ 
		ok=false;
		_flushall(); 
		printf("Aizpildit masivu ar gadijuma skaitliem?[y/n]");
		scanf("%c",&ans);

		if((ans=='Y')||(ans=='n')||(ans=='y')||(ans=='N')) ok=true;
	}while(ok!=true);
	//*/
	//ans='Y';

	CLS;
	
	//aizpildam masivu
	if((ans=='Y')||(ans=='y')){
		srand(time(NULL));
		for(int i=0;i<n;i++) arr[i]=rand()%100;
	}
	else{
		int num;
		for(int i=0;i<n;i++) {
			system("cls");
			
			printf("arr[%d]: ",i);
			num=(int)spellCheck("Value=");
			
			arr[i]=num;
		}
	}
	
	CLS;
	//izvadam masivu bez izmainam
	//aprekinam summu, sum1 - mainigie; sum2 - raditaji
	int sum=sum1(arr,n);

	printf("Izvadam masivu bez izmainam.\n");	
	for(int i=0;i<n;i++) printf("arr[%d]=%d\n",i,arr[i]);
	printf("Elementu summa ir:\nsum=%d\n",sum);
	delay();
	
	//izsaucam 1 f-ju kas lieto mainigos
	//un izvadam izmainitu masivu
	printf("Izsaucam 1-ro f-ju un izvadam masiva saturu.\n");
	f1(arr,n,sum);
	for(int i=0;i<n;i++) printf("arr[%d]=%d\n",i,arr[i]);
	delay();
	
	//izsaucam 2 f-ju kas lieto raditajus
	//un izvadam izmainitu masivu*/
	printf("Izsaucam 2-ro f-ju un izvadam masiva saturu.\n");
	f2(arr,n,sum);
	for(int i=0;i<n;i++) printf("arr[%d]=%d\n",i,arr[i]);
	delay();
	
	printf("Programma beidz darbibu.");
	delay();
}
