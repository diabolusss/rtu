/*     ld2.cpp rdbfo5 Vitalijs Hodiko
 *  2. laboratorijas darbs "MASiVU APSTRaDE"
Sast?d?t programmu, kas paredz?ta mas?va apstr?dei. 
Programmai j?sast?v no galven?s funkcijas un div?m apak?programm?m (funkcij?m). 
Katr? funkcij? j?veic viena un t? pati mas?va apstr?de, 
bet vienas funkcijas realiz??anai j?lieto main?gie ar indeksiem, otras - r?d?t?ji.
 Funkcij?m j?nodod mas?vs un t? indeksu aug??j?s robe?as (mas?vs ir lok?lais main?gais). 
Galvenaj? funkcij? paredz?t: inform?cijas izvadi par autoru,
 mas?vu aizpildi un izvadi, 
 apak?programmu (funkciju) izsaukumus.
  Programmas p?rbaudei izmantot abus mas?vu izm?rus.
Mas?va aizpildes veidu (ar gad?juma skait?iem vai patst?v?gi ievad?ti elementi) var izv?l?ties lietot?js.
Parveidot viendimensijas masivu ta, 
lai katrs elements butu vienads ar 
starpibu starp elementu summu un 
atbilstoso sakummasiva elementu. |15|,| 25|

	dinamic arr*/
	//#include <stdlib.h> ///* declares malloc //*/
	//...
	//int *a;
	//a = malloc(n * sizeof(int));
	//a[3] = 10;
	//this can be changed as needed (using the standard library function realloc).
 

#include "prg_def.h"

int main(){
	int choice;
	while(choice!=3){
	
		CLS;
		printf("#### Menu ####################################\n");
		printf("####                                      ####\n");
		printf("#### 1 #Informacija par autoru un uzdevumu####\n");
		printf("#### 2 #Uzdevuma izpilde                  ####\n");
		printf("#### 3 #EXIT                              ####\n");
		printf("####                                      ####\n");
		printf("##############################################\n");
		
		printf("Please, enter only numbers:\n");
		choice=(int)spellCheck("MENU:");

		
		switch(choice){
			case 1:title();
				   break;
			case 2:uzd();
				   break;
			case 3:break;
			default:break;
		}
	}
return 0;	
}
