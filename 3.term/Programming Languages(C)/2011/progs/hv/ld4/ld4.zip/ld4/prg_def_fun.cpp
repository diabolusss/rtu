#include "prg_def.h"

//izvada uzdevumu
void title(){
	printf("##########################################\n"
	       "####             Vitalijs  Hodiko     ####\n"
		   "####             RDBF05 091REB325     ####\n"
		   "##########################################\n"
		   "####     4 lab.d. DARBS AR FAILU      ####\n"
		   "####   *Sakumdati tiek:               ####\n"
		   "####    -nolasiti no faila            ####\n"
		   "####    -papildinati no tastaturas    ####\n"
		   "####   *Faila jabut vismaz 15 ieraksti####\n"
		   "####                                  ####\n"
		   "####                                  ####\n"
		   "##########################################\n"
		   "####    Uzdevuma variants             ####\n"
		   "####    1.Sastadit programmu, kas     ####\n"
		   "####        apstrada sadu strukturu   ####\n"
		   "####        par studentiem:           ####\n"
		   "####         �	 Vards                ####\n"
		   "####         �	 Uzvards              ####\n"
		   "####         �	 Apliecibas numurs    ####\n"
		   "####         �	 Videja atzime        ####\n"
		   "####                                  ####\n"
		   "##########################################\n"
		   "####  Programma paredzet:             ####\n"
		   "####   c.Atrast studentu, kura        ####\n"
		   "####        vards/uzvards sakas ar    ####\n"
		   "####        lietotaja ievadito simbolu####\n"
		   "####        virkni                    ####\n"
		   "####                                  ####\n"
		   "####                                  ####\n"
		   "##########################################\n");
	delay();
	}

//parbauda ievaditas informacijas atbilstibu
int isNum(char* num){
 int count=0;

 for(int i=0;i<strlen(num);i++){
  if (num[i]=='\n') num[i]='\0';
  if (isdigit(num[i])) count++;

 }

 if (count<(strlen(num)) || strlen(num)==0) return -1;
 else {
  count=atoi(num);
  return count;
 }
}

//skaitla ievade
int enterNum(char* msg,int length){
 int number=-1;
 char* num=(char*)calloc(length,sizeof(char));
 
 do{
  _flushall();
  printf("\n%s:",msg);
  fgets(num,length,stdin);
  number=isNum(num);
 }while(number<0);
 
 return number;
}

//gaida taustina nospiesanu
void delay(){
     int ok;
	do{ 
	_flushall();
	 
		ok=true;
		char answer;
		

		
		printf("\nPress any key...\n\n");
		scanf("%c",&answer);
		

	}while(not ok);
}

//meklejam non alphabet chars un ja atrodam izmainam to uz '\0'
int stopCheck(char* chptr){
   int result=false;
   char ch=*chptr;
   //array of stop chars
   //everithing you want to be as stop char add here
   char stops[]=". !,@#$%^&*()_+|[]{}:;'<>/\\?1234567890`~-=";
   
   for(int i=0;i<strlen(stops);i++){
    //printf("[%c]==[%c]result=%d\n",ch,stops[i],result);
    if((ch==stops[i])||(ch=='\n')){
	 
	 *chptr='\0';
     result=true;
     break;
    }
   }   
   return result;
}

//parbaudam cik pirmo simbolu sakrit
int contains(char *str0,char *key){

	int ok=false,result=strlen(key);
	
	//printf("\nstr0=%s; key=%s",str0,key);
	//make search for key in str0
	///*
	for(int i=0;i<strlen(key);i++){
     if(str0[i]==key[i]) result--;
	}

	//printf("\n\nstr0=%s; key=%s; result=%d\n\n",str0,key,result);
	if (result==0) return 1;
	else return 0;
}

//===============DARBS AR FAILU==================//
//----------------uzinam faila garumu
int fileSize(FILE* tFile){

 fseek(tFile,0,SEEK_SET);
 
 applicant_history* student=(applicant_history *)malloc(sizeof(applicant_history));
 
 int i=0; 
 while(fread(student,sizeof(applicant_history),1,tFile)!=0) i++;
 
 fseek(tFile,0,SEEK_SET);
 
 free(student);
 return i;
}

//----------------ievadam informaciju rekordaa
applicant_history* scanApp(){
 applicant_history* student = (applicant_history*)malloc(sizeof(applicant_history));
 
 printf("\nEnter first name:");  scanf("%s", student ->name); 
 printf("\nEnter second name:"); scanf("%s", student ->surname); 
 printf("\nEnter ID:");          scanf("%s", student ->ID); 
 printf("\nEnter mark:");        scanf("%d",&student ->mark); 

return student; 
}

//----------------izvada  recorda saturu
void displayApp(applicant_history* Student,int cur){
 printf("\n|%2d |%15s |%15s |%15s |%4d|",cur+1, 
 Student->name,
 Student->surname,
 Student->ID,
 Student->mark); 
}

//----------------rezervejam atminu masivam
applicant_history** initMas(int size){

  //Allocate space for array in memory (num,size)
 applicant_history **history=NULL;

  /* add ONE element to the array */
 history=(applicant_history**)calloc(size,sizeof(applicant_history*));

 /* allocate memory for arrCount `applicant_history` */
 for(int i=0;i<size;i++){
  history[i] = (applicant_history *)malloc(sizeof(applicant_history));
  } 
 return history;  
}

//----------------atbrivojam masivam rezervetu atminu
void freeMas(applicant_history** student,int *sizeptr){
 /* free all history elements */
 int size=*sizeptr;
 printf("\nsize=%d\n",size);
 for(int i=0;i<size;i++)  free(student[i]); free(student);
 size=0;
 *sizeptr=size;
}
	