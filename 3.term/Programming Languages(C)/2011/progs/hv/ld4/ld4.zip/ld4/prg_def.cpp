#include "prg_def.h"

FILE* fillFile(FILE* tFile){
 applicant_history* student=(applicant_history *)malloc(sizeof(applicant_history));
 char* st=(char*)malloc(sizeof(char));
 
 int arrCount=41;
 
  for(int i=0;i<arrCount;i++){
   //student=scanApp();
   st="StudentName";
    strcpy(student->name,st);
   st="StudentSurName";   
    strcpy(student->surname,st);
   st="091RBD123";   
    strcpy(student->ID,st);
   student->mark=i;
   
   fwrite(student,sizeof(applicant_history),1,tFile);
  }
  free(student);
  
  fseek(tFile,0,SEEK_SET);
}

//izveidot jaunu failu
FILE* fOpen(applicant_history** student){
 unsigned char option;
 FILE* tFile=NULL;
 
 _flushall();
 printf("[1] read existing file\n[2] create an empty file for writing\n");
 
 scanf("%c",&option);

 if (option=='1') {
  printf("option: %c\n",option);
  
  tFile=fopen(constfName,"rb");
  
  if (tFile!=NULL)  printf("File is ready for reading\n");  
  else printf("Illegal operation! There is no such file\n");
 }else if (option=='2'){
   printf("option: %c\n",option);
   
   tFile=fopen(constfName,"wb");
   
   tFile=fillFile(tFile);
   if (tFile!=NULL) printf("New file successfully created\n");
   
  }
 
 return tFile;  
}

//kopejam faila saturu masiva, lai atrak stradatu ar masiviem failiem
//visas izmainas notiks masiva un pec tam parrakstitas faila
applicant_history** file2Mas(FILE *tFile,applicant_history** student,int *sizeptr){

  tFile=fopen(constfName,"rb");
  
  int size=fileSize(tFile);  

  *sizeptr=size;
  student=initMas(size);  
  
 int ii=0;
 while(fread(student[ii],sizeof(applicant_history),1,tFile)!=0)  ii++;
 
 fclose(tFile);

 return student;
}

//parrakstam masivu faila ar izmainitu informaciju
void mas2File(FILE* tFile,applicant_history** student,int size){
 tFile=fopen(constfName,"wb");
 

 for(int i=0;i<size;i++){
  fwrite(student[i],sizeof(applicant_history),1,tFile);
 }
}

//papildinam masivu ar jaunu ierakstu jebkura vieta
applicant_history** addRecord(applicant_history** student,int *sizeptr){
 applicant_history** tMas=NULL;
 
 int size=*sizeptr,num; 
 
 mView(student,size);
 printf("\nENTER number where to place new student:"); 
 
 ++*sizeptr;
 size++;
 
 do{
  num=enterNum("\nStudent number:",3);
 }while((num>size)||(num<1));
 num--;
 
 tMas=initMas(size);

 for(int i=0;i<num;i++){
  tMas[i]=student[i];
 }
 tMas[num]=scanApp();
 num++;
 
 for(int i=num;i<size;i++){
  tMas[i]=student[i-1];
 } 
 
 return tMas;
}

//izdzesam ierakstu no masiva
applicant_history** delRecord(applicant_history** student,int *sizeptr){
 int size=*sizeptr,num;
 
 mView(student,size);
 printf("ENTER student number to delete:");
 
 do{
  num=enterNum("\nStudent number:",3);
 }while((num>size)||(num<1));
 
 num--;
 
 size--; 
 applicant_history** newStudent=initMas(size);

 for(int i=0;i<num;i++){
  newStudent[i]=student[i];
 }
 for(int i=num;i<size;i++){
  newStudent[i]=student[i+1];
 }
 
 *sizeptr=size;

 //printf("size=%d\n",*sizeptr);
 mView(newStudent,size);

 return newStudent;
}

//meklejam pec varda vai uzvarda
void makeSearch(applicant_history** student,int size){
 char *chptr, *key=(char*)calloc(wstr,sizeof(char));
 
 do{
   _flushall();
   printf("\nEnter name to find:");
   fgets(key,wstr,stdin);
 
   for(int i=0;i<strlen(key);i++){
    chptr=&key[i];
    if(stopCheck(chptr)) break;  
   }
 }while(strlen(key)==0);
 
 for(int i=0;i<size;i++){
  if (contains(student[i]->name,key)==true) displayApp(student[i],i);
 }
}

//masiva saturs
void mView(applicant_history** student,int size){
 int maxCell=20,ok=true,x=0,y;
 char *key=(char*)malloc(sizeof(char)*2);
 
 do{
    if(maxCell*(x+1)<size) y=maxCell*(x+1);
    else y=size;  
	
  //if(ok) {
   CLS;
   printf("\n--------------------------------------------------------------\n");
   printf("|%s |%15s |%15s |%15s |%s|","No","Name","Surname","ID","Mark");
   printf("\n--------------------------------------------------------------");
   for(int i=x*maxCell;i<y;i++)  displayApp(student[i],i);
   printf("\n--------------------------------------------------------------\n");
   printf("\n%s - quit %10s - previous %10s - next %s - accept\n","q","w","s","ENTER");
   ok=false;
  //}
  
  _flushall();
  fgets(key,2 ,stdin);

  switch(key[0]){
   case 119://up   w
            if(x) {
			 x--;
			 //ok=true;
			}
			break;
   case 115://down s
            if((x+1)*maxCell<size) {
			 x++;
			 //ok=true;
			}
			break;
  }
  //printf("\nkey[%d]=%c; x=%d\n",*key,key,x);
 }while(*key!=113);
}

void uzd(){
	int size=0,*sizeptr=&size,choice=-1;
	FILE *pFile=NULL;
	applicant_history** fileData=NULL;

	while(choice!=6){
	
		CLS;
		printf("#### Menu ####################################\n"
		       "####                                      ####\n"
			   "#### 1 #OPEN FILE                         ####\n"
			   "#### 2 #VIEW FILE                         ####\n"
			   "#### 3 #ADD STUDENT                       ####\n"
			   "#### 4 #DELETE STUDENT                    ####\n"
			   "#### 5 #FIND STUDENT                      ####\n"
			   "####                                      ####\n"
			   "####                                      ####\n"
			   "#### 6 #RETURN                            ####\n"
			   "####                                      ####\n"
			   "##############################################\n");
		
		printf("Please, enter only numbers:\n");
		choice=enterNum("MENU",2);
		

		
		switch(choice){
			case 1://OPEN FILE
				   pFile=fOpen(fileData);
				   fileData=file2Mas(pFile,fileData,sizeptr);
				   //printf("\nsize=%d\n",size);
				   delay();
				   break;
			case 2://VIEW FILE 			       fView(pFile);		       
                   if(fileData) mView(fileData,size);
				   else         printf("Illegal operation\n");
				    delay(); 
				   break;
			case 3://ADD STUDENT 
			       if(fileData){
					fileData=addRecord(fileData,sizeptr);
                    //printf("\nsize=%d\n",size);				   
                    mView(fileData,size);
					delay(); 
                    mas2File(pFile,fileData,size);					
				   }
				   else {
				    printf("Illegal operation\n");
				    delay(); 
				   }
				   break;
			case 4://DELETE STUDENT
			       if((fileData)&&(size>0)){
				    fileData=delRecord(fileData,sizeptr);
					mas2File(pFile,fileData,size);
				   }
				   else {
				    printf("Illegal operation\n");
				    delay(); 
				   }
				   break;
			case 5://FIND STUDENT
			       if((fileData)&&(size>0)){
                    mView(fileData,size);
				    //delay();
		            makeSearch(fileData,size);
                   }
                   else printf("Illegal operation\n");
				   delay(); 
				   break;					   
			case 6:if(fileData)freeMas(fileData,sizeptr);
			       if(pFile)fclose(pFile);
			       break;
		}
	}
}


