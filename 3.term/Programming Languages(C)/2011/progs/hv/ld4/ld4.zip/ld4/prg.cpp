/*     ld2.cpp rdbfo5 Vitalijs Hodiko
void title(){
	printf("##########################################\n");
	printf("####             Vitalijs  Hodiko     ####\n");
	printf("####             RDBF05 091REB325     ####\n");
	printf("##########################################\n");
	printf("####     4 lab.d. DARBS AR FAILU      ####\n");
	printf("####   *Sakumdati tiek:               ####\n");
	printf("####    -nolasiti no faila            ####\n");
	printf("####    -papildinati no tastaturas    ####\n");
	printf("####   *Faila jabut vismaz 15 ieraksti####\n");
	printf("####                                  ####\n");
	printf("####                                  ####\n");
	printf("##########################################\n");
	printf("####    Uzdevuma variants             ####\n");
	printf("####    1.	Sastadit programmu, kas   ####\n");
	printf("####        apstrada sadu strukturu   ####\n");
	printf("####        par studentiem:           ####\n");
	printf("####         �	 Vards                ####\n");
	printf("####         �	 Uzvards              ####\n");
	printf("####         �	 Apliecibas numurs    ####\n");
	printf("####         �	 Videja atzime        ####\n");	
	printf("####                                  ####\n");	
	printf("##########################################\n");
	printf("####  Programma paredzet:             ####\n");
	printf("####   c.	Atrast studentu, kura     ####\n");
	printf("####        vards/uzvards sakas ar    ####\n");
	printf("####        lietotaja ievadito simbolu####\n");
	printf("####        virkni                    ####\n");	
	printf("####                                  ####\n");	
	printf("####                                  ####\n");	
	printf("##########################################\n");
	delay();
	}*/

#include "prg_def.h"

int main(){
	int choice;
	
	while(choice!=3){
	
		CLS;
		printf("#### Menu ####################################\n"
		       "####                                      ####\n"
		       "#### 1 #Informacija par autoru un uzdevumu####\n"
		       "#### 2 #Uzdevuma izpilde                  ####\n"
		       "#### 3 #EXIT                              ####\n"
		       "####                                      ####\n"
		       "##############################################\n");
		
		printf("Please, enter only numbers:\n");
        choice=enterNum("MENU",2);
		
		switch(choice){
			case 1:title();
				   break;
			case 2:uzd();
				   break;
			case 3:break;
			default:break;
		}
	}
return 0;	
}
