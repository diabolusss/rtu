#ifndef PRG_DEF_H
	#define PRG_DEF_H 1

	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <ctype.h>

	#define true 1
	#define false 0
	
	#define wstr 15 /* String width */
    #define nstr 2 /* Number of strings */
	
    #define constfName "labd4.bin"

	//win	system("cls");	//unix system("clear");
	
	#ifdef __unix__
		#define CLS system("clear");
	#elif defined _WIN32 // _WIN32 is defined by most compilers available for the Windows operating system (but not by all).
		#define CLS system("cls");
	#else
		#error "What's your operating system?"
	#endif
typedef struct{
 char name[wstr],surname[wstr],ID[wstr];
 unsigned mark;
}applicant_history;

	//function prototipes
	void title();
	
	int isNum(char* );
	int enterNum(char* ,int );
	
	void uzd();
	void delay();
	
    int stopCheck(char* );	
	int contains(char *,char *);

	FILE* fOpen(applicant_history** );
	
	int fileSize(FILE* );
	
	applicant_history** file2Mas(FILE *,applicant_history** );
	
	applicant_history*  scanApp();	
	void                displayApp(applicant_history* ,int );
	
	applicant_history** initMas(int );	
	void                freeMas(applicant_history** ,int * );
	
	FILE* fillFile(FILE* );
	
	applicant_history** file2Mas(FILE* ,applicant_history** ,int* );
	void                mas2File(FILE* ,applicant_history** ,int );
	
	applicant_history** addRecord(applicant_history** ,int* );
	applicant_history** delRecord(applicant_history** ,int* );
	
	void mView(applicant_history** ,int );
	


#endif
