/*
		datu strukturas 1 uzd
		Vitalijs Hodiko 091REB325

Uzdevums:
	Izstrâdât algoritmu un izveidot programmu,
 kas veido masîvu no veseliem elementiem (Integer) 
 un izpilda ðâdu funkciju secîbu (sk. tabulâ). 

Numuri pec saraksta|Masîva veids		|Izmers|Izpildâmâs funkcijas
2, 10, 18, 26		Divdimensijas masivs 4x4	1, 2b, 3, 4


Funkciju saraksts, kuru numuri atrodas pedeja tabulas kolonna:
1.	Masiva ievade no tastaturas.
2.	Masiva elementa un vina vietas (indeksu) meklesana,
	 kura sakrit ar doto atslegu X (meklesanas atslegu uzdod lietotajs).
	 Paredzet situaciju, kad dota elementa masîva var ari nebut.
	 Meklesanas procesu organizet ar sadu algoritmu:
		a)lineara meklesana, izmantojot robezmarkiera metodi
3.	Masiva izvade uz ekrana.
4.	Noteikt AMF (Adrress Mapping Function) funkciju masivam, 
	 ja masiva sakumadrese bus b=1000. 
*/
#include <iostream>
#include <stdio.h>
#include <cstdlib>
#define n 4
using namespace std;

int amf(int x, int y){
    int l = 4;
    int b = 1000;
    int c2 = l;
    int c1 = (3-0+1)*c2;
    int c0 = b-c1*0-c2*0;
    
    int amf = c0 + 16*x+4*y;
    printf("\namf=c0+16*x+4*y\n");
    printf("AddressMappingFunction: arr[%d][%d] adrese ir %d \n", x,y,amf);
return amf;   
}

int lSearch(int array[n][n],int key,int*p1,int*p2,int *arr,int *status)
{
 int i,j,q=0,t=0;
 for(i=0;i<n;i++)
  {
   for(j=0;j<n;j++)
    {
	//printf("array[%d][%d]=%d\n",i,j,array[i][j]);
	 if(array[i][j]==key)
      {
       *p1=i;*p2=j;
       arr[t]=i;t++;
       arr[t]=j;t++;
       *status+=1;
      }
    }
  }
return *status;
}


int main(){
int mas[n][n],res[n*n];
int i,j,x,count=0,y=-130;
srand(time(NULL));
system("clear");

for( i=0;i<n;i++){
 for( j=0;j<n;j++){
    mas[i][j]=rand()%10;
    printf("[%d][%d]=%d \n",i,j,mas[i][j]);
 }
}                   
printf("Ievadiet vertibu,kuru vajag atrast\n key=");cin>>y;  
count=lSearch(mas,y,&x,&y,res,&count);
if(count>0){
    printf("\nAtrasta atslega=%d, %d reizes :\n",mas[x][y],count);
    for(int q=0;q<2*count;q+=2){
	printf("mas[%d][%d]\n",res[q],res[q+1]);}
	}
else{printf("\nAtslega=%d nav atrasta\n",y);}

    printf("\nAMF\n Ievadiet masiva[x][y] koordinates\n");
    printf("x=");scanf("%d",&x);
    printf("y=");scanf("%d",&y);
    amf(x,y);
    
    system("PAUSE");
 
}
