Transmission client server proramm.

To run in console type:
	#to run server
	java -jar TServer.jar
	#to run client
	java -jar TClient.jar

In the same place where server jar is runned, directory 'Home' with files 'command.list' and 'server.about' in it should be.
This errors and many others should be eliminated.

DB commands are case sensitive

