package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.Date;

import libs.SystemData;


public class ClientManager extends Thread{

	private Socket sock = null;
	private String ip;
	private String port;
	private static boolean stop = false;
	public ClientManager(Socket _sock){
		sock = _sock;
		
		try {
			sock.setSoTimeout(500);
			ip = sock.getInetAddress().toString();
			port = Integer.toString(sock.getPort());
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void run(){
		System.out.println("Client manager");
		
		ServGUI.addInfoRow(
				new Object[]{sock.getInetAddress(),sock.getPort(),SystemData.getFormatedTime("def", new Date())}
				);	
		BufferedReader in = null;
		PrintWriter out = null;
		String strin = "";
		try {
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			out = new PrintWriter(new OutputStreamWriter(sock.getOutputStream()));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		stop = false;
		while(true){
			try {
				strin = in.readLine();
				if(strin == null)
					break;
				
				
				out.println(Protocol.procQuery(strin,sock));
				out.flush();
				if(strin.equalsIgnoreCase("exit")){
					out.println("Bye!!!");
					break;
				}
			} catch(SocketTimeoutException e){
				if(stop || sock.isClosed())
					break;
				continue;
			} catch (IOException e) {
				break;
			}
						
			
		}
		
		
		try {
			sock.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally{
			ServGUI.delRow(ip,port);
			}
		System.out.println("Manager closed");
		
	}
	
	public static void stopClientManager(){
		stop = true;
	}

}
