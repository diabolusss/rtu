package server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.Socket;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import libs.SystemData;

public class Protocol {
	private static String COMMAND_LIST = "list";
	private static String COMMAND_GET = "get";
	/*
	 * private static String COMMAND_GET = "get";
	 * private static String COMMAND_REPORT = "report";
	 */
	
	public static String procQuery(String query, Socket _sock){
		if(query == null)
			return "";
		
		System.out.println("PROC: " + query);
		if(query.equals(COMMAND_LIST)){
			
			File list = new File(SystemData.getFileDir());
			
			
			return FileList(list.list(new FilenameFilter() {
				
				@Override
				public boolean accept(File dir, String name) {
					return name.matches(".*\\..*");
				}
			}));
		}
		else if (query.startsWith(COMMAND_GET)){
			PrintWriter out = null;
			BufferedReader in = null;
			try {
				out = new PrintWriter(_sock.getOutputStream(), true);
				in = new BufferedReader(new InputStreamReader(_sock.getInputStream()));
			} catch (IOException e) {
				
			}
			String fname = query.substring(query.indexOf("|")+1,query.length());
			
			
			File list = new File(SystemData.getFileDir() + File.separatorChar + fname);
			
			out.println(list.length());
			out.flush();
			
			
			
			
		}
		return null;
	}
	
	private static String FileList(String[] _list){
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = null;
		try {
			docBuilder = docFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Document doc = docBuilder.newDocument();
		Element root = doc.createElement("data");
		doc.appendChild(root);
		Element files = doc.createElement("files");
		
		root.appendChild(files);
		
		Element name = null;
		Element size = null;
		Element file = null;
		
		for(String item : _list){
			file = doc.createElement("file");
			name = doc.createElement("name");
			name.appendChild(doc.createTextNode(item));
			file.appendChild(name);
			size = doc.createElement("size");
			size.appendChild(doc.createTextNode(Long.toString(new File(SystemData.getFileDir() + "/" + item).length())));
			file.appendChild(size);
			files.appendChild(file);
		}
		
		
		doc.normalize();
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = null;
		try {
			transformer = tf.newTransformer();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		StringWriter writer = new StringWriter();
		try {
			transformer.transform(new DOMSource(doc), new StreamResult(writer));
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return writer.getBuffer().toString().replaceAll("\n|\r", "");
		
		
	    
	}
}
