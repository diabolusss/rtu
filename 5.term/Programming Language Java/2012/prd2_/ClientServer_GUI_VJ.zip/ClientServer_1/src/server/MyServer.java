package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;


public class MyServer extends Thread{

	private ServerSocket  servSock = null;
	private static boolean stop = false;
	private static int port = 1234;
	private class CMTH{
		public Socket sock;
		public Thread thrd;
	}
	private List<CMTH> cliData = new ArrayList<CMTH>();
	
	public static void main(String[] args) {
		
		if(args.length>0 && Integer.parseInt(args[0])!= 0)
			port = Integer.parseInt(args[0]);
		MyServer server = new MyServer();
		MyServer.setPort(port);
		server.run();
	}
	
	
	public static void setPort(int _port){
		port = _port;
	}
	
	public void run(){
		CMTH cmth = new CMTH();
		System.out.println("Test");
		try {
			servSock = new ServerSocket(port);
			System.out.println("PORT is " + port);
			servSock.setSoTimeout(500);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stop = false;
		while(true){
			try {
				cmth.sock = servSock.accept();
				cmth.thrd = new Thread(new ClientManager(cmth.sock));
				cmth.thrd.setPriority(Thread.NORM_PRIORITY);
				cmth.thrd.setDaemon(false);
				cmth.thrd.start();
				cliData.add(cmth);

				System.out.println("Connected client #" + cliData.size());
			}catch(SocketTimeoutException e){
				if (stop == true)
					break;
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			chkCli();
		}
		
		disconnectClients();
		chkCli();
		
		try {
			servSock.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Stopped");
	}
	
	private void chkCli(){
		for(int i=0;i<cliData.size();i++){
			if(!cliData.get(i).thrd.isAlive()){
				try {
					cliData.get(i).sock.close();
				} catch (IOException e) {
				}
				cliData.remove(i);
			}
		}
	}
	
	private void disconnectClients(){
		ClientManager.stopClientManager();
	}
	
	
	public static void stopServ(){
		stop = true;
	}
	
	
	

}