package server;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Date;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import libs.SystemData;


public class ServGUI {
	private static Frame frm = new Frame("Servera informācija");
	private static Object[][] data = new Object[][] { };
	
	private static DefaultTableModel dataModel = new DefaultTableModel(data,
			new String[] {"Ip adrese", "Ports", "Savienots"});
	private static JTable table = new JTable(dataModel);
	private static Thread sThread = null;
	
	public static void main(String[] args){
		
		
		final MyServer serv = new MyServer();
		
		final Panel actPanel = new Panel();
		final Panel stsPanel = new Panel();
		final Label stsLabel = new Label("Servera status");
		final Label stsInfoLabel = new Label("neaktīvs");
		
		JScrollPane cliInfoPanel = new JScrollPane(table);
		
		
		final JButton startServerButton = new JButton("",new ImageIcon(ServGUI.class.getResource("/images/start.png")));
		final JButton stopServerButton = new JButton("",new ImageIcon(ServGUI.class.getResource("/images/stop.png")));
		final JButton confButton = new JButton("",new ImageIcon(ServGUI.class.getResource("/images/settings.png")));
		
		stopServerButton.setEnabled(false);
		
		startServerButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
			    MyServer.setPort(SystemData.getSrvPort());
				sThread = new Thread(serv);
				sThread.setDaemon(false);
				sThread.setPriority(Thread.NORM_PRIORITY);
				sThread.start();
				
				stsInfoLabel.setText("strāda no " + SystemData.getFormatedTime("def", new Date()));
				startServerButton.setEnabled(false);
				stopServerButton.setEnabled(true);
				confButton.setEnabled(false);
				frm.pack();
				
			}
		});
		
		stopServerButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				MyServer.stopServ();
				stsInfoLabel.setText("neaktīvs");
				startServerButton.setEnabled(true);
				stopServerButton.setEnabled(false);
				confButton.setEnabled(true);
			}
		});
		
		confButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				showConfigFrame();
				
			}
		});
		actPanel.add(startServerButton);
		actPanel.add(stopServerButton);
		actPanel.add(confButton);
		
		table.getColumnModel().getColumn(0).setPreferredWidth(100);
		table.getColumnModel().getColumn(1).setPreferredWidth(50);
		table.getColumnModel().getColumn(2).setPreferredWidth(150);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	
		cliInfoPanel.setBackground(Color.LIGHT_GRAY);
		cliInfoPanel.setPreferredSize(new Dimension(318,100));
						
		stsPanel.add(stsLabel);
		stsPanel.add(stsInfoLabel);
		
		
		frm.add(actPanel,BorderLayout.PAGE_START);
		frm.add(stsPanel, BorderLayout.AFTER_LAST_LINE);
		frm.add(cliInfoPanel,BorderLayout.CENTER);
		frm.pack();
		frm.setResizable(false);
		
		
		frm.addWindowListener(new WindowAdapter()
		{
			public void windowClosing (WindowEvent event) {
		        System.exit (0);
		    }
		});
		
		
		frm.setLocation(100, 100);
		frm.setVisible(true);
		
	}
	
	public static void addInfoRow(Object[]  obj){
		System.out.println("ADD");
		dataModel.addRow(obj);
	}
	
	public static void delRow(String ip, String port){
		System.out.println(ip + "=>" + port);
		for(int i=0;i<dataModel.getRowCount();i++){
			System.out.println("TAB: " + table.getValueAt(i, 0) + "=>" + table.getValueAt(i, 1));
			if(table.getValueAt(i, 0).toString().equals(ip) && table.getValueAt(i, 1).toString().equals(port)){
				System.out.println("Deleted " + i);
				dataModel.removeRow(i);
				dataModel.fireTableDataChanged();
			}
		}
	}
	
	public static void showConfigFrame(){
		
		final JFrame cFrame = new JFrame();
		final JDialog dCFrame = new JDialog(cFrame,"Uzstādījumi", true);
		
		
		final JLabel dFLabel = new JLabel("Datuma formats");
		final JLabel folderLabel = new JLabel("Direktorija ar failiem");
		final JLabel lblPort = new JLabel("Servera ports:");
		
		final JTextField folder = new JTextField(15);
		final JTextField srvPortText = new JTextField(5);
		final JTextField dateFormat = new JTextField(15);
		
		final JFileChooser fChooser = new JFileChooser(SystemData.getFileDir());
		folder.setText(SystemData.getFileDir());
		srvPortText.setText(Integer.toString(SystemData.getSrvPort()));
		dateFormat.setText(SystemData.getMask());
		
		final JPanel srvPort = new JPanel();
		final JPanel panBtn = new JPanel();
		final JPanel panDir = new JPanel();
		final JPanel panMain = new JPanel();
		final JPanel panDate = new JPanel();
		
		
		
		final JButton btnSave = new JButton("Saglabat");
		final JButton btnCancel = new JButton("Atcelt");
		final JButton btnChgDir = new JButton("Mainīt");
		
		fChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		folder.setText(fChooser.getCurrentDirectory().toString());
		folder.setCaretPosition(0);
		folder.setMaximumSize(new Dimension(300,20));
		
		panMain.setLayout(new BoxLayout(panMain, BoxLayout.Y_AXIS));
		
		srvPort.add(lblPort);
		srvPort.add(srvPortText);
		
		
		panBtn.add(btnSave);
		panBtn.add(btnCancel);
	
		panDir.add(folderLabel);
		panDir.add(folder);
		panDir.add(btnChgDir);
		
		panDate.add(dFLabel);
		panDate.add(dateFormat);
		
		panMain.add(srvPort);
		panMain.add(panDate);
		panMain.add(panDir);
		panMain.add(panBtn);
		
		
		btnChgDir.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(fChooser.showDialog(null, "Izveleties")==JFileChooser.APPROVE_OPTION){
					folder.setText(fChooser.getSelectedFile().toString());
				}
				
			}
		});
		
		btnSave.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SystemData.setMask(dateFormat.getText());
				SystemData.setFileDir(folder.getText());
				SystemData.setSrvPort(Integer.parseInt(srvPortText.getText()));
				dCFrame.dispose();				
			}
		});
		
		
		dCFrame.addWindowListener(new WindowAdapter()
		{
			public void windowClosing (WindowEvent event) {
		        dCFrame.setVisible(false);
		    }
		});
		
		
		btnCancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dCFrame.dispose();
				
			}
		});
		
		dCFrame.add(panMain);
		dCFrame.setSize(500, 300);
		//dCFrame.pack();
		dCFrame.setVisible(true);
		
		
		
		
	}
}
