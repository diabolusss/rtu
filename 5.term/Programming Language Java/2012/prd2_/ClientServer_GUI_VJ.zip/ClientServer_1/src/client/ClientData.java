package client;

public class ClientData {
	
	private int port = 1234;
	private String addr = "127.0.0.1";
	
	public int getPort() {
		return port;
	}
	
	public void setPort(int _port) {
		port = _port;
	}
	
	public String getAddr() {
		return addr;
	}
	
	public void setAddr(String _addr) {
		addr = _addr;
	}
	
	

}
