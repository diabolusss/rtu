package client;

import java.awt.BorderLayout;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class ClientError {
	
	public static void showMessage(JFrame parent, Exception e, boolean gui){
		if(gui){
			showFrame(e, parent);
		}else{
			System.out.println("Exception:" + e.getMessage());
		}
	}
	
	public static void showFrame(Exception e, JFrame parent){
		JDialog dialog = new JDialog();
		JLabel lbl = new JLabel(e.getMessage());
		JTextArea desc = new JTextArea(e.getStackTrace().toString());
		
		dialog.add(lbl,BorderLayout.BEFORE_FIRST_LINE);
		dialog.add(desc,BorderLayout.AFTER_LAST_LINE);
		dialog.pack();
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.setVisible(true);
		
		
	}

}
