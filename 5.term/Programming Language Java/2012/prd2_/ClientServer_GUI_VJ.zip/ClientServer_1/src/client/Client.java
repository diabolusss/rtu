package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.Socket;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Client {
	private Socket sock;
	
	public boolean connect(String server, int port){
		try {
			sock = new Socket(server, port);
		} catch (Exception e) {
			ClientError.showMessage(null, e, false);
			return false;
		}
		return true;
	}
	
	public void disconnect(){
		try {
			sock.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<Object[]> getFileList(){
		PrintWriter out = null;
		BufferedReader in = null;
		String xmlData = null;
		ArrayList<Object[]> ret = new ArrayList<Object[]>();
        try {
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			out = new PrintWriter(sock.getOutputStream(), true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        out.println("list");
        
        try {
        	xmlData = in.readLine();
			System.out.println("MYLI: " + xmlData);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        StringReader sr = new StringReader(xmlData);
        InputSource src = new InputSource(sr);
        
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = null;
        Document doc = null;
        try {
			db = dbf.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			doc = db.parse(src);
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        NodeList fNodes =  doc.getElementsByTagName("file");
    
       for(int i=0;i<fNodes.getLength();i++){
        	Element file = (Element) fNodes.item(i);
        	Element fname = (Element) file.getElementsByTagName("name").item(0);
        	Element fsize = (Element) file.getElementsByTagName("size").item(0);
        	
        	ret.add(new Object[]{fname.getTextContent(),fsize.getTextContent()});
        }
        
        return ret;

	}

}
