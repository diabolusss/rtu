package client;


import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.AbstractCellEditor;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;


public class ClientGUI {
	private static JFrame mainFrame = new JFrame();
	private Client mycli = new Client();
	private ClientData config = new ClientData();
	private Object [][] dataObject = new Object[][]{};
	private DefaultTableModel fTabModel = new DefaultTableModel(dataObject,
			new String[]{"Nosaukums","Izmers","Iespejas"});
	private JTable fileTable = new JTable(fTabModel){

		private static final long serialVersionUID = 7428189058997804987L;

		public boolean isCellEditable(int rowIndex, int colIndex) {
			  return colIndex==2; //Disallow the editing of any cell
			  }
	};
	
	private class ProcessButton extends AbstractCellEditor implements TableCellEditor, TableCellRenderer {

		private static final long serialVersionUID = -4803308269697801981L;
		private JButton proc = null;
		
		public ProcessButton(){
			proc = new JButton("Testas");
			proc.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					JOptionPane.showMessageDialog(null, "Reading ");
					
				}
			});
			proc.setEnabled(true);
		}
		
		@Override
		public Object getCellEditorValue() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Component getTableCellRendererComponent(JTable arg0,
				Object arg1, boolean arg2, boolean arg3, int arg4, int arg5) {
			// TODO Auto-generated method stub
			return proc;
		}

		@Override
		public Component getTableCellEditorComponent(JTable arg0, Object arg1,
				boolean arg2, int arg3, int arg4) {
			// TODO Auto-generated method stub
			return proc;
		}
		
	}
	
		
	public static void main(String[] args){
		
		ClientGUI cli = new ClientGUI();
		cli.showMainFrame();
	}
	
	public void showMainFrame(){
		JPanel headPanel = new JPanel();
		final JScrollPane bodyPanel = new JScrollPane(fileTable);
		final JPanel actionPanel = new JPanel();
		//	JPanel footerPanel = new JPanel();
		
		
		JPanel mainPanel = new JPanel();
		
		final JButton connectButton = new JButton("Pievienoties",new ImageIcon(ClientGUI.class.getResource("/images/start.png")));
		final JButton disconnectButton = new JButton("Atvienoties",new ImageIcon(ClientGUI.class.getResource("/images/stop.png")));
		JButton settingButton = new JButton("Uzstadījumi",new ImageIcon(ClientGUI.class.getResource("/images/settings.png")));
		JButton listButton = new JButton("Failu saraksts");
		
		disconnectButton.setEnabled(false);
		
		fileTable.getColumnModel().getColumn(0).setPreferredWidth(100);
		
		fileTable.getColumnModel().getColumn(1).setPreferredWidth(100);
		fileTable.getColumnModel().getColumn(2).setPreferredWidth(100);
		fileTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		fileTable.getTableHeader().setReorderingAllowed(false);
		fileTable.getColumnModel().getColumn(2).setCellRenderer(new ProcessButton());
		fileTable.getColumnModel().getColumn(2).setCellEditor(new ProcessButton());
		
		fTabModel.addRow(new Object[] {"123123123","234","Button"});
		
		headPanel.add(connectButton);
		headPanel.add(disconnectButton);
		headPanel.add(settingButton);
		
		actionPanel.add(listButton);
		actionPanel.setVisible(false);
		
		bodyPanel.setPreferredSize(new Dimension(318,150));
		bodyPanel.setBackground(Color.BLUE);
		bodyPanel.setVisible(false);
		
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		mainPanel.add(headPanel);
		mainPanel.add(actionPanel);
		mainPanel.add(bodyPanel);
		
		updateFrameTitle();
		mainFrame.add(mainPanel);
		mainFrame.setVisible(true);
		mainFrame.pack();
		
		settingButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				settingFrame();
				
			}
		});
		
		listButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				final ArrayList<Object[]> data = mycli.getFileList();
				for(Object[] obj : data){
					fTabModel.addRow(obj);
				}
			}
		});
		
		connectButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				
				if(mycli.connect(config.getAddr(), config.getPort())){
					disconnectButton.setEnabled(true);
					connectButton.setEnabled(false);
					actionPanel.setVisible(true);
					bodyPanel.setVisible(true);
					mainFrame.pack();
				}
			}
		});
		
		disconnectButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				actionPanel.setVisible(false);
				bodyPanel.setVisible(false);
				mainFrame.pack();
				fTabModel.getDataVector().clear();
				mycli.disconnect();
			}
		});
		
		
	}
	
	
	private void updateFrameTitle(){
		mainFrame.setTitle("Server - " + config.getAddr() + ":" + Integer.toString(config.getPort()));
	}
	
	private void settingFrame(){
		JFrame settingFrame = new JFrame();
		final JDialog dialog = new JDialog(settingFrame,"Uzstadījumi",true);		
		
		JPanel mainPanel = new JPanel();
		
		JPanel portPanel = new JPanel();
		JPanel addrPanel = new JPanel();
		JPanel buttonPanel = new JPanel();
		
		
		JLabel portLabel = new JLabel("Servera ports: ");
		JLabel addrLabel = new JLabel("Servera adrese: ");
		
		final JTextField portField = new JTextField(Integer.toString(config.getPort()),4);
		final JTextField addrField = new JTextField(config.getAddr(),10);
		
		JButton saveButton = new JButton("Saglabat");
		JButton cancelButton = new JButton("Atcelt");
		
		
		portPanel.add(portLabel);
		portPanel.add(portField);
		
		addrPanel.add(addrLabel);
		addrPanel.add(addrField);
		
		buttonPanel.add(saveButton);
		buttonPanel.add(cancelButton);
		
		mainPanel.add(addrPanel);
		mainPanel.add(portPanel);
		mainPanel.add(buttonPanel);
		
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		
	
		saveButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				config.setAddr(addrField.getText());
				config.setPort(Integer.parseInt(portField.getText()));
				updateFrameTitle();
				dialog.setVisible(false);
			}
		});
		
		cancelButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog.setVisible(false);				
			}
		});
		
		dialog.add(mainPanel);
		dialog.pack();
		dialog.setVisible(true);
	}
}

