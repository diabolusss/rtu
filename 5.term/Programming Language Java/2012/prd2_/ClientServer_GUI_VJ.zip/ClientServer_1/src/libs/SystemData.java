package libs;
import java.text.SimpleDateFormat;
import java.util.Date;


public class SystemData {
	
	private static String defDateMask = "dd-MM-yyyy HH:MM:ss";
	private static int srvPort = 1234;
	private static String fileDir = System.getProperty("user.dir");
	public static String getFormatedTime(String format, Date date){
		if(format.equals("def"))
			format = SystemData.defDateMask;
		SimpleDateFormat df = new SimpleDateFormat(format);
		return df.format(date);
	}
	
	public static String getMask(){
		return SystemData.defDateMask;
	}
	
	public static void setMask(String _mask){
		SystemData.defDateMask = _mask;
	}

	public static int getSrvPort() {
		return srvPort;
	}

	public static void setSrvPort(int srvPort) {
		SystemData.srvPort = srvPort;
	}

	public static String getFileDir() {
		return fileDir;
	}

	public static void setFileDir(String fileDir) {
		SystemData.fileDir = fileDir;
	}

}
