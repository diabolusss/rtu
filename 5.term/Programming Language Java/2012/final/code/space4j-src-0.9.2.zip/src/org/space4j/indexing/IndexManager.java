/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.indexing;


import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.space4j.Command;
import org.space4j.CommandException;
import org.space4j.LoggerException;
import org.space4j.Space4J;


/**
 * IndexManager will control all indexes for your space.
 * 
 * @author Sergio Oliveira Jr.
 */
public class IndexManager implements Serializable {
    
    private static final Set<Index<?>> EMPTY = new HashSet<Index<?>>();
    
    public static final String KEY = "sys_IndexManager";
    
    private Map<String, Set<Index<?>>> indexesByClassname = new Hashtable<String, Set<Index<?>>>(); // all indexes will be here...
    
    private Map<String, Index<?>> indexesByName = new Hashtable<String, Index<?>>();
    
    /**
     * Drop an index from the system.
     * 
     * @param indx The index to drop
     * @param space4j The space4j where this command will be executed.
     * @return boolean True if the index was dropped.
     */
    public boolean dropIndex(Index<?> indx, Space4J space4j) throws CommandException, LoggerException {
    	
        Command cmd = new DropIndexCmd(indx);
        
        int x = space4j.exec(cmd);
        
        return x > 0;
    }
    
    boolean dropIndexImpl(Index<?> indx) {
    	
        String name = indx.getClassName();
        
        // first remove from indexesByClassname...
        
        Set<Index<?>> set = (Set<Index<?>>) indexesByClassname.get(name);
        
        if (set != null) {
        	
            set.remove(indx);
        	
            if (set.size() == 0) {
                indexesByClassname.remove(name);
            }
        	
        }
        
        // finally remove from indexesByName...

        return indexesByName.remove(indx.getName()) != null;
    }
    
    private Iterator<Index<?>> getIndexes(Class<? extends Object> klass) {
    	
        String name = klass.getName();
        
        Set<Index<?>> set = (Set<Index<?>>) indexesByClassname.get(name);
        
        if (set == null) {
            return EMPTY.iterator();
        }
        
        return set.iterator();
    }    
    
    /**
     * Insert an object in this IndexManager.
     * 
     * All indexes that index this object will be updated.
     * 
     * @param obj The object to be inserted.
     */
    public void add(Object obj, Object source) {
    	
        Iterator<Index<?>> iter = getIndexes(obj.getClass());
        
        while (iter.hasNext()) {
        	
            Index<?> indx = iter.next();
            
            if (!indx.getSource().equals(source)) {
                continue;
            }
            
            indx.index(obj);
        }
    }
    
    /**
     * Remove an object from this IndexManager.
     * 
     * All the indexes that index this object will be updated.
     * 
     * @param obj The object to be removed.
     */
    public void remove(Object obj, Object source) {
    	
        Iterator<Index<?>> iter = getIndexes(obj.getClass());
        
        while (iter.hasNext()) {
        	
            Index<?> indx = iter.next();
            
            if (!indx.getSource().equals(source)) {
                continue;
            }
            
            indx.remove(obj);
        }
    }
    
    /**
     * Check if an index with that name already exists.
     * 
     * @param name The name of the index
     * @return true if it exists
     */
    public boolean checkIndex(String name) {
    	
        return indexesByName.containsKey(name);
    	
    }
    
    /**
     * Return an index with that name.
     * 
     * @param name The name of the index.
     * @return the index or null if it doesn't exist.
     */
    public <T> Index<T> getIndex(String name) {
    	
        return (Index<T>) indexesByName.get(name);
    }
    
    /**
     * Create an index in the system.
     * 
     * @param indx The index to be created.
     * @param space4j The space4j were this command will be executed.
     * @return True if the index was created.
     */
    public boolean createIndex(Index<?> indx, Space4J space4j) throws CommandException, LoggerException {
    	
        if (indexesByName.containsKey(indx.getName())) {
    		
            throw new CommandException("Index already exists!");
        }
    	
        Command cmd = new CreateIndexCmd(indx);
        
        int x = space4j.exec(cmd);
        
        return x > 0;
    }
    
    /*
     * CreateIndexCmd will call this method.
     */
    void createIndexImpl(Index<?> indx, Collection<?> list) {
    	
        indx.init(list);
        
        // save the maps...
        indexesByName.put(indx.getName(), indx);
        
        Set<Index<?>> set = indexesByClassname.get(indx.getClassName());
        
        if (set == null) {
        	
            set = new HashSet<Index<?>>();
        	
            indexesByClassname.put(indx.getClassName(), set);
        }
        
        set.add(indx);
    }
}
    
