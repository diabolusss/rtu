/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.indexing;


import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListMap;


/**
 * An object representing an Index in the system.
 * An index contains a name, a classname, and a set o attributes.
 * Index can be simple or compound.
 */
public class Index<E> implements Serializable {
	
    private static final boolean DEBUG = false;
	
    public static enum TYPE {
        MULTI, MULTI_SORTED, SORTED, REGULAR
    };
    
    private String name;
    private Object source;
    private String classname;
    private String simpleClassname;
    private String[] attributes;
    private TYPE type;
    
    private Object indexMap;
    private Map<Object, Key> keyMap;
    
    private Comparator<Key> comparator;
    
    private transient Method[] methods = null;
    
    /**
     * Create a new Index.
     * @param name The name of this index.
     * @param klass The class of this index.
     * @param attributes An array of attributes.
     */
    public Index(String name, Object source, TYPE type, Class<? extends Object> klass, String... attributes) {
    	
        this(name, source, type, null, klass, attributes);
    }
    
    public Index(String name, Object source, TYPE type, Comparator<Key> comp, Class<? extends Object> klass, String... attributes) {
    	
        this.name = name;
        this.source = source;
        this.classname = klass.getName();
        this.simpleClassname = klass.getSimpleName();
        this.attributes = attributes;
        this.type = type;
        
        if (comp == null) {
        	
            this.comparator = new KeyComparator();
        	
        } else {
        	
            this.comparator = comp;
        }
        
        this.indexMap = getMap(type, this.comparator);
        
        this.keyMap = new HashMap<Object, Key>();
    }
    
    public Comparator<Key> getComparator() {
    	
        return comparator;
    }
    
    public Object getSource() {
    	
        return source;
    }
    
    public TYPE getType() {
    	
        return type;
    }
    
    public <T> T getMap() {
    	
        return (T) indexMap;
    }
    
    Map<Object, Key> getKeyMap() {
    	
        return keyMap;
    }
    
    protected String getTypeName(TYPE type) {
    	
        switch (type) {
    	
        case MULTI:
			
            return "MULTI";
			
        case MULTI_SORTED:
			
            return "MULTI_SORTED";
			
        case REGULAR:
			
            return "REGULAR";
			
        case SORTED:
			
            return "SORTED";
			
        default:
			
            throw new IllegalArgumentException("Don't know this type!");
		
        }
    }
    
    protected <T> T getMap(TYPE type, Comparator<Key> comparator) {
    	
        switch (type) {
    	
        case MULTI:
    			
            return (T) new MultiMap<E>();
    				
        case MULTI_SORTED:
    			
            return (T) new MultiSortedMap<E>(comparator);
    			
        case REGULAR:
    			
            return (T) new ConcurrentHashMap<Key, E>(16, 0.75f, 1);
    			
        case SORTED:
    			
            return (T) new ConcurrentSkipListMap<Key, E>(comparator);
    			
        default:
				
            throw new IllegalArgumentException("Don't know this type!");
        }
    }
    
    /**
     * Return the name of this index.
     * @return The name of the index.
     */
    public String getName() {
        return name;
    }
    
    /**
     * Return the name of the class of this index.
     * @return The name of the class.
     */
    public String getClassName() {
        return classname;
    }
    
    /**
     * Return the attributes of this index.
     * @return The attributes of the index.
     */
    public String[] getAttributes() {
        return attributes;
    }
    
    /**
     * Check if this index contains a given attribute.
     * @param attribute The attribute we are looking for.
     * @return True if the index contains this attribute.
     */
    public boolean hasAttribute(String attribute) {
        for (int i = 0; i < attributes.length; i++) {
            if (attributes[i].equalsIgnoreCase(attribute)) {
                return true;
            }
        }
        return false;
    }
    
    /*
     * Needs performance improvements.. (cache!)
     */
    private void findMethods(Class<? extends Object> klass) {
        
        // for security...
        if (!klass.getName().equalsIgnoreCase(this.classname)) {
            return;
        }
        
        try {
            methods = new Method[attributes.length];
            
            for (int i = 0; i < methods.length; i++) {
                String name = getMethodName(attributes[i]);

                methods[i] = klass.getDeclaredMethod(name, (Class[]) null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            methods = null;
        }
    }
    
    private String getMethodName(String attribute) {
        String firstletter = attribute.substring(0, 1);
        StringBuffer sb = new StringBuffer("get");

        sb.append(firstletter.toUpperCase());
        sb.append(attribute.substring(1, attribute.length()));
        return sb.toString();
    }
    
    void init(Collection<?> coll) {
    	
        Iterator<?> iter = coll.iterator();
    	
        while (iter.hasNext()) {
    		
            Object obj = iter.next();
    		
            Key key = getKey(obj);
    		
            if (type == TYPE.MULTI) {
	        	
                MultiMap<Object> mm = (MultiMap<Object>) indexMap;
	        	
                mm.putObject(key, obj);
	        	
            } else if (type == TYPE.MULTI_SORTED) {
	        	
                MultiSortedMap<Object> msm = (MultiSortedMap<Object>) indexMap;
	        	
                msm.putObject(key, obj);
                
            } else if (type == TYPE.REGULAR || type == TYPE.SORTED) {
            	
            	Map<Key, Object> map = (Map<Key, Object>) indexMap;
            	
            	map.put(key, obj);
	        	
            }    		
    		
            keyMap.put(obj, key);
    		
        }
    }
    
    void index(Object obj) {
    	
        /*
         * How do we know the key whith which the object was indexed?
         * 
         * The object has now changed and we have no way to recalculating the key,
         * therefore we store the key in a object -> key map.
         */
    	
        if (DEBUG) {
        	
            System.out.print("Indexing: ");
            System.out.print(this);
            System.out.print(" = ");
            System.out.println(obj);
        }
        
        Key oldkey = (Key) keyMap.get(obj);
        
        if (oldkey != null) {
        	
            if (type == TYPE.MULTI) {
        		
                MultiMap<Object> mm = (MultiMap<Object>) indexMap;
        		
                mm.removeObject(oldkey, obj); // remove the old index with the old key...
        		
            } else if (type == TYPE.MULTI_SORTED) {
        		
                MultiSortedMap<Object> msm = (MultiSortedMap<Object>) indexMap;
        		
                msm.removeObject(oldkey, obj); // remove the old index with the old key...
        		
            } else if (type == TYPE.SORTED || type == TYPE.REGULAR) {
            	
            	Map<Key, Object> map = (Map<Key, Object>) indexMap;
        	
                map.remove(oldkey); // remove the old index with the old key...
        		
            }
        }
        
        Key key = getKey(obj); // generate new key...
        
        if (type == TYPE.MULTI) {
        	
            MultiMap<Object> mm = (MultiMap<Object>) indexMap;
        	
            mm.putObject(key, obj);
        	
        } else if (type == TYPE.MULTI_SORTED) {
        	
            MultiSortedMap<Object> msm = (MultiSortedMap<Object>) indexMap;
        	
            msm.putObject(key, obj);
        	
        } else if (type == TYPE.SORTED || type == TYPE.REGULAR) {
        	
        	Map<Key, Object> map = (Map<Key, Object>) indexMap;
        
            map.put(key, obj);
        	
        }
        
        keyMap.put(obj, key); // this will replace the old key for the new one...
        
    }
    
    boolean remove(Object obj) {
    	
        if (DEBUG) {
            System.out.print("Removing: ");
            System.out.print(this);
            System.out.println(" = ");
            System.out.println(obj);
        }

        Key oldkey = (Key) keyMap.remove(obj);
        
        if (oldkey == null) {
            return false;
        }
        
        if (type == TYPE.MULTI) {
        	
            MultiMap<Object> mm = (MultiMap<Object>) indexMap;
        	
            mm.removeObject(oldkey, obj);
        	
        } else if (type == TYPE.MULTI_SORTED) {
    		
            MultiSortedMap<Object> msm = (MultiSortedMap<Object>) indexMap;
    		
            msm.removeObject(oldkey, obj); // remove the old index with the old key...
        	
        } else if (type == TYPE.SORTED || type == TYPE.REGULAR) {
        	
        	Map<Key, Object> map = (Map<Key, Object>) indexMap;
        	
            map.remove(oldkey);
        }
        
        return true;
    }
    
    /**
     * Get a key to be used by this index for a given object.
     * @param value The object from which we want a key.
     * @return A key for this object.
     */
    public Key getKey(Object value) {
        
        // Find methods if needed...
        if (methods == null) {
            synchronized (this) {
                if (methods == null) {
                    findMethods(value.getClass());
                }
            }
        }
        
        // If it is not possible to find methods return null...
        if (methods == null) {
        	
            System.err.println(
                    "Could not find prop methods: " + value + " / "
                    + value.getClass().getName());
        	
            return null;
        }
        
        Key key = new Key();
        
        try {
            for (int i = 0; i < methods.length; i++) {
                Object obj = methods[i].invoke(value, (Object[]) null);

                key.add(obj);
            }
        } catch (Exception e) {
            
            System.err.println(
                    "Could not get prop by reflection: "
                            + value.getClass().getName());
        	
            e.printStackTrace();
            
            return null;
        }
        
        return key;
    }
    
    public boolean equals(Object obj) {
        if (!(obj instanceof Index)) {
            return false;
        }
        
        Index<?> indx = (Index<?>) obj;

        return indx.getName().equals(this.name);
    }
    
    public int hashCode() {
        return name.hashCode();
    }
    
    public String toString() {
        StringBuffer sb = new StringBuffer();

        sb.append("Index: ").append(name).append(" ").append(source);
        sb.append(" ").append(getTypeName(type)).append(" ").append(
                simpleClassname);
        sb.append(" (");
        for (int i = 0; i < attributes.length; i++) {
            sb.append(attributes[i]).append(",");
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.append(")");
        sb.append(" SIZE=").append(keyMap.size());
        return sb.toString();
    }
    
}
        
