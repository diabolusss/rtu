/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.implementation;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Iterator;

import org.space4j.Command;
import org.space4j.CommandException;
import org.space4j.LoggerException;
import org.space4j.command.IncrementSeqCmd;


/**
 * The master space4j in the center of the replication ring.
 * It will execute all commands and send them to the slaves, so they can execute them too.
 */
public class MasterSpace4J extends SimpleSpace4J implements Runnable {
    
    private int master_port = 4000;
    private int slave_port = 4001;
    
    private ServerSocket ss;
    private HashMap<InetAddress, ObjectOutputStream> slaves = new HashMap<InetAddress, ObjectOutputStream>();
    private Thread listener;
    
    private long[] unique_replica_id = { 0L };
    
    /**
     * Initializes the MasterSpace4J.
     * @param dirname The dir where the space is stored.
     * @see SimpleSpace4J
     */
    public MasterSpace4J(String dirname) throws LoggerException, CommandException {
        super(dirname);
    }
    
    public MasterSpace4J(String dirname, long snapTime) throws LoggerException, CommandException {
        super(dirname, snapTime);
    }
    
    /**
     * Initializes the MasterSpace4J.
     * @param dirname The dir where the space is stored.
     * @param master_port The port where the master will be listening.
     * @param slave_port The port where the slaves will be listening.
     * @see SimpleSpace4J
     */
    public MasterSpace4J(String dirname, long snapTime, int master_port, int slave_port) throws LoggerException, CommandException {
        this(dirname, snapTime);
        this.master_port = master_port;
        this.slave_port = slave_port;
    }
    
    public MasterSpace4J(String dirname, int master_port, int slave_port) throws LoggerException, CommandException {
        this(dirname, -1, master_port, slave_port);
    }

    /**
     * Start listening for slaves.
     */
    public void start() throws UnknownHostException, IOException, ClassNotFoundException {
        super.start();
        listener = new Thread(this);
        listener.setDaemon(true);
        listener.start();
    }
    
    // connect back to slaves...
    // the master will notify the slaves of changes (commands) through here...
    void connectToSlave(InetAddress slave_ip) throws SocketException, IOException {
        Socket socket = new Socket(slave_ip, slave_port);
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());

        synchronized (slaves) {
            slaves.put(slave_ip, oos);
        }
    }
    
    // send a just executed command to the slaves, so they can execute it too...
    private void notifySlaves(Command cmd) {
    	if (slaves != null) {
	        synchronized (slaves) {
	            Iterator<ObjectOutputStream> iter = slaves.values().iterator();
	
	            while (iter.hasNext()) {
	                ObjectOutputStream oos = iter.next();
	
	                try {
	                    oos.writeObject(cmd);
	                } catch (IOException e) {
	                    // we lost a slave
	                    // close the connection and remove it from the ring...
	                    e.printStackTrace();
	                    try {
	                        oos.close();
	                    } catch (Exception exc) {}
	                    iter.remove();
	                }
	            }
	        }
    	}
    }
    
    // if you are reapplying, there is no need for logging, and also no need for notifying the slaves...
    public synchronized int exec(Command cmd, boolean log) throws CommandException, LoggerException {
        
        int x = super.exec(cmd, log);
    	
        if (log) {
        	
            if (cmd instanceof IncrementSeqCmd) {
        		
                IncrementSeqCmd isc = (IncrementSeqCmd) cmd;
        		
                isc.setSequence(x);
            }
        	
            notifySlaves(cmd);
        }
        return x;
    }
    
    // get an unique id for the slave...
    long getUniqueReplicaId() {
        synchronized (unique_replica_id) {
            return ++unique_replica_id[0];
        }
    }
    
    public void run() {
        
        try {
            
            ss = new ServerSocket(master_port);
        
            while (true) {
            
                try {
                    
                    Socket socket = ss.accept();
                    Thread client = new SlaveThread(this, socket);

                    client.start();
                    // System.out.println("Slave connected !!!");
                    
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
                

/*
 * This thread will wait for commands coming from the slaves.
 * All commands must be executed first in the slaves.
 */
class SlaveThread extends Thread {
    
    private MasterSpace4J space4j;
    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private InetAddress slave_ip;
    
    private boolean bThread = true;
    
    public SlaveThread(MasterSpace4J space4j, Socket socket) {
        this.space4j = space4j;
        this.socket = socket;
    }
    
    public void run() {
        
        try {
        
            slave_ip = socket.getInetAddress();
        
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            
            // send a unique id to the slave...
            out.writeObject(new Long(space4j.getUniqueReplicaId()));
        
            space4j.connectToSlave(slave_ip);
        
            // just wait for commands from the slave...
            while (bThread) {
                Command cmd = (Command) in.readObject();

                space4j.exec(cmd);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}        

        
