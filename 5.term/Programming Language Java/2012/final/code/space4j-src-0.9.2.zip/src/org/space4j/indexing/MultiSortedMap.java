/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.indexing;


import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListMap;


public class MultiSortedMap<V> extends ConcurrentSkipListMap<Key, Set<V>> {
	
	private static final int SET_POOL_INIT_SIZE = 512;
	
    private final Set<V> EMPTY = new HashSet<V>(0);
	
    private final LinkedList<Set<V>> SET_POOL = new LinkedList<Set<V>>();
	
    public MultiSortedMap(Comparator<Key> comparator) {
		
        super(comparator);
		
        for (int i = 0; i < SET_POOL_INIT_SIZE; i++) {
			
            SET_POOL.add(createNewSet());
			
        }
    }
    
    private Set<V> createNewSet() {
    	
    	return Collections.newSetFromMap(new ConcurrentHashMap<V, Boolean>(16, 0.75f, 1));
    }
	
    public void putObject(Key key, V value) {
		
        Set<V> set = super.get(key);
		
        if (set == null) {
			
            set = SET_POOL.poll();
			
            if (set == null) set = createNewSet();
			
            super.put(key, set);
        }
        
        set.add(value);
    }
	
    public boolean removeObject(Key key, V value) {
		
        Set<V> set = super.get(key);
		
        if (set == null) return false;
		
        boolean removed = set.remove(value);
		
        if (set.size() == 0) {
			
            super.remove(key);
			
            SET_POOL.offer(set);
        }
		
        return removed;
    }
    
    public CollectionOfSets<V> subMapValues(Key fromKey, boolean fromInclusive, Key toKey, boolean toInclusive) {
    	
    	return new CollectionOfSets<V>(super.subMap(fromKey, fromInclusive, toKey, toInclusive).values());
    }
    
    public CollectionOfSets<V> subMapValues(Key fromKey, Key toKey) {
    	
    	return new CollectionOfSets<V>(super.subMap(fromKey, toKey).values());
    }
    
    public CollectionOfSets<V> tailMapValues(Key fromKey) {
    	
    	return new CollectionOfSets<V>(super.tailMap(fromKey).values());
    }
    
    public CollectionOfSets<V> tailMapValues(Key fromKey, boolean inclusive) {
    	
    	return new CollectionOfSets<V>(super.tailMap(fromKey, inclusive).values());
    }
    
    public CollectionOfSets<V> headMapValues(Key toKey) {
    	
    	return new CollectionOfSets<V>(super.headMap(toKey).values());
    }
    
    public CollectionOfSets<V> headMapValues(Key toKey, boolean inclusive) {
    	
    	return new CollectionOfSets<V>(super.headMap(toKey, inclusive).values());
    }
    
    public CollectionOfSets<V> descendingMapValues() {
    	
    	return new CollectionOfSets<V>(super.descendingMap().values());
    }
    
    public CollectionOfSets<V> ascendingMapValues() {
    	
    	return new CollectionOfSets<V>(super.values());
    }
    
    @Override
    public Set<V> remove(Object key) {
		
        throw new UnsupportedOperationException(
                "Cannot call this function for MultiMap");
    }
	
    @Override
    public Set<V> get(Object key) {
       
       Set<V> set = null;
       
       if (key instanceof Key) {
          
          set = super.get(key);
          
       } else {
          
          set = super.get(new Key(key));
       }
		
        if (set != null) return set;
			
        return EMPTY;
    }
	
    public Set<V> get(Object... keys) {
		
        Set<V> set = super.get(new Key(keys));
		
        if (set != null) return set;
			
        return EMPTY;
    }	
}
