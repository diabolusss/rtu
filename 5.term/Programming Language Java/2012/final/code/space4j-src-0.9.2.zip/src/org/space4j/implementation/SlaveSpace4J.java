/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.implementation;


import org.space4j.*;

import java.io.*;
import java.util.*;
import java.net.*;


/**
 * This is complex, but it works.
 * Users of Space4J do not have to understand this to use the system.
 * The true power of encapsulation and simplicity.
 */
public class SlaveSpace4J extends SimpleSpace4J implements Runnable {
    
    private int master_port = 4000;
    private int slave_port = 4001;
    private ServerSocket ss;
    private String master_ip;
    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private boolean takingsnapshot = false;
    private Object snapshotLock = new Object();
    private LinkedList<Command> list = new LinkedList<Command>();
    private long lognumber = -1;
    private int retval;
    private long replica_id = 0L;
    
    /**
     * Initializes the SlaveSpace4J.
     * @param dirname The dir where the space is stored.
     * @param master_ip The ip address of the master.
     * @see SimpleSpace4J
     */
    public SlaveSpace4J(String dirname, long snapTime, String master_ip) throws LoggerException, CommandException {
        super(dirname, snapTime);
        this.master_ip = master_ip;
    }
    
    public SlaveSpace4J(String dirname, String master_ip) throws LoggerException, CommandException {
    	
        this(dirname, -1, master_ip);
    }
    
    /**
     * Initializes the SlaveSpace4J.
     * @param dirname The dir where the space is stored.
     * @param master_ip The ip address of the master.
     * @param master_port The port the master is listening.
     * @param slave_port The port this slave will be listening.
     * @see SimpleSpace4J
     */
    public SlaveSpace4J(String dirname, long snapTime, String master_ip, int master_port, int slave_port) throws LoggerException, CommandException {
        this(dirname, snapTime, master_ip);
        this.master_port = master_port;
        this.slave_port = slave_port;
    }
    
    public SlaveSpace4J(String dirname, String master_ip, int master_port, int slave_port) throws LoggerException, CommandException {
    	
        this(dirname, -1, master_ip, master_port, slave_port);
    	
    }
    
    public void start() throws UnknownHostException, IOException, ClassNotFoundException {
        super.start();
        Thread listener = new Thread(this);

        listener.setDaemon(true);
        listener.start();
        Thread executer = new CommandExecuter(this, list);

        executer.setDaemon(true);
        executer.start();
        connectToMaster();
    }
    
    // connect to master and get an unique slave id...
    private void connectToMaster() throws UnknownHostException, IOException, ClassNotFoundException {
        socket = new Socket(master_ip, master_port);
        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());
        Long x = (Long) in.readObject();

        this.replica_id = x.longValue();
    }
    
    private void sendCommandToMaster(Command cmd) throws IOException {
        cmd.setReplicaId(replica_id);
        out.writeObject(cmd);
    }
    
    public synchronized int exec(Command cmd) throws CommandException {
        // local command being executed in the slave
        // slave needs to send it to the master
        try {
            sendCommandToMaster(cmd);
            wait(); // wait for the master to execute it...
            return retval;
        } catch(InterruptedException e) {
        	throw new CommandException(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommandException(e.getMessage());
        }
    }
    
    // execute a list of commands...
    void executeCommands(ArrayList<Command> list) {
        Iterator<Command> iter = list.iterator();

        while (iter.hasNext()) {
            Command cmd = iter.next();

            try {
                executeCommandLocally(cmd);
            } catch (CommandException e) {
                e.printStackTrace();
            } catch (LoggerException e) {
                e.printStackTrace();    
            }
        }
    }

    void executeCommandFromMaster(Command cmd) throws CommandException {
        // add the command to the linkedlist and wake up the commandexecuter thread
        synchronized (list) {
            list.add(cmd);
            synchronized (snapshotLock) {
                if (!takingsnapshot) {
                    list.notify();
                }
            }
        }
    }

    synchronized int executeCommandLocally(Command cmd) throws CommandException, LoggerException {
        lognumber = cmd.getLogNumber();
        retval = super.exec(cmd, false);
        if (cmd.getReplicaId() == replica_id) {
            notify();
        }
        return retval;
    }
    
    public void executeSnapshot() throws LoggerException {
        synchronized (snapshotLock) {
            takingsnapshot = true;
        }
        
        try {
            logger.takeSnapshot(space, lognumber);
        } catch (LoggerException e) {
            e.printStackTrace();
            throw e;
        } finally {
            synchronized (snapshotLock) {
                takingsnapshot = false;
            }
            synchronized (list) {
                list.notify();
            }
        }
    }    

    // accept connection from the master...
    // master may die or it may need to reconnect
    // master may also change...
    // that's why this is threaded in an infinite loop...
    public void run() {
        
        try {
            
            ss = new ServerSocket(slave_port);
        
            while (true) {
            
                try {
                    
                    Socket socket = ss.accept();
                    Thread client = new MasterThread(this, socket);

                    client.start();
                    
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
                

// the slave will receive commands from the master here...
class MasterThread extends Thread {
    
    private SlaveSpace4J space4j;
    private Socket socket;
    private ObjectInputStream in;
    
    private boolean bThread = true;
    
    public MasterThread(SlaveSpace4J space4j, Socket socket) {
        this.space4j = space4j;
        this.socket = socket;
    }
    
    public void run() {
        
        try {
        
            in = new ObjectInputStream(socket.getInputStream());
        
            while (bThread) {
                Command cmd = (Command) in.readObject();

                space4j.executeCommandFromMaster(cmd);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


// this is a producer/consumer thread, backed-up by a linked list...
class CommandExecuter extends Thread {
    
    private SlaveSpace4J space4j;
    private LinkedList<Command> list;
    private boolean bThread = true;
    
    public CommandExecuter(SlaveSpace4J space4j, LinkedList<Command> list) {
        this.space4j = space4j;
        this.list = list;
    }
    
    public void run() {
        while (bThread) {
            try {
                ArrayList<Command> al = null;

                synchronized (list) {
                    while (list.size() == 0) {
                        list.wait();
                    }
                    al = new ArrayList<Command>(list);
                    list.clear();
                }
                space4j.executeCommands(al);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}        

                
