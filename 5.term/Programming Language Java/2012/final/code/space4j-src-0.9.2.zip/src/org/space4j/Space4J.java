/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j;


import java.io.IOException;
import java.net.UnknownHostException;


/**
 * Our Java database of objects. Clients will use the Space4J object to execute commands in the
 * underlying space. Space4J will be running in the same JVM the client is running, in other words, the client will be
 * able to access the Space4J directly in memomy.
 */
public interface Space4J {
    
    /**
     * Re-apply a command on the underlying Space.
     * 
     * This method will be used to re-apply the commands from the logs.
     * 
     * OBS: Logging is done AFTER the command is executed. If, for some reason, a CommandException is thrown, the command will not be logged.
     *
     * @param cmd The command to execute.
     * @return An int containing the number of objects modified by this operation.
     * @throws CommandException if there is a problem executing this command
     * @throws LoggerException if there is a problem logging thie command
     */
    public int reapply(Command cmd) throws CommandException, LoggerException;

    /**
     * Executes a command on the underlying Space.
     * 
     * The client must use this method to perform any update on the Space.
     * 
     * The client must never do any modifications on the Space objects without using this method,
     * otherwise, the change will not be persisted.
     * 
     * Space4J will execute the command and log the changes for future recovery if needed.
     * 
     * OBS: Logging is done AFTER the command is executed. If, for some reason, a CommandException is thrown, the command will not be logged.
     *
     * @param cmd The command to execute.
     * @return An int containing the number of objects modified by this operation.
     * @throws CommandException if there is a problem executing this command
     * @throws LoggerException if there is a problem logging thie command
     */
    public int exec(Command cmd) throws CommandException, LoggerException;
    
    /**
     * Take a snapshot of the Space to disk. The Space will be serialized and written to disk.
     */
    public void executeSnapshot() throws LoggerException;
    
    /**
     * Returns the Space where the Objects are stored, so the client can direct access them.
     * 
     * @return a Space if Space4J is running locally or null otherwise
     */
    public Space getSpace();
    
    /**
     * Starts the Space4J. This is only necessary for a replicated Space4J.
     */
    public void start() throws UnknownHostException, IOException, ClassNotFoundException;
    
}
