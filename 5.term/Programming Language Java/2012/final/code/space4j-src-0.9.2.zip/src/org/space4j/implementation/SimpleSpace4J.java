/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.implementation;


import java.io.IOException;
import java.net.UnknownHostException;

import org.space4j.Command;
import org.space4j.CommandException;
import org.space4j.Logger;
import org.space4j.LoggerException;
import org.space4j.Space;
import org.space4j.Space4J;
import org.space4j.command.CreateObjectCmd;
import org.space4j.indexing.IndexManager;


/**
 * The simplest possible implementation of a Space4J.
 */
public class SimpleSpace4J implements Space4J, Runnable {
    
    protected Space space;
    protected Logger logger;
    protected String dirname;
    protected IndexManager im;
    
    protected Thread thread = null;
    protected long snapTime;
   
    /**
     * Initializes the SimpleSpace4J, initializes the Logger, recover the Space from disk if there is a snapshot saved
     * and reapply the commands to the Space.
     */
    public SimpleSpace4J(String dirname, long snapTime) throws LoggerException, CommandException {
        this.dirname = dirname;
        logger = new SimpleLogger(dirname);
        space = readSnapshot();
        if (space == null) {
            space = new SimpleSpace();
        }
        reapplyCommandsFromLog();
        
        im = space.getIndexManager();
        
        if (im == null) {
            
            // let's have an index manager no matter what...
            
            try {
        	
                exec(new CreateObjectCmd(IndexManager.KEY, new IndexManager()));
                
                im = space.getIndexManager();
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        this.snapTime = snapTime;
        
        if (snapTime > 0) {
        	
            thread = new Thread(this);
        	
        }
    }
    
    public SimpleSpace4J(String dirname) throws LoggerException, CommandException {
    	
        this(dirname, -1);
    }
    
    public String getDirName() {
        return dirname;
    }
    
    public Space getSpace() {
        return space;
    }
    
    public void run() {
    	
        while (true) {
    		
            try {
    			
                Thread.sleep(snapTime);
    			
                executeSnapshot();
    			
            } catch (InterruptedException e) {
    			
                return;
    			
            } catch (Exception e) {
    			
                System.err.println("Error taking snapshot!");
    			
                e.printStackTrace();
            }
    		
        }
    	
    }
    
    public void start() throws UnknownHostException, IOException, ClassNotFoundException { 
        // initialize the IndexManager
        this.im = (IndexManager) space.get(IndexManager.KEY);
        
        if (thread != null) {
            thread.start();
        }
    }
    
    /**
     * Execute a command and log it.
     * @param cmd The command to be executed and logged.
     * @return The number of objects modified by this operation.
     */
    public synchronized int exec(Command cmd) throws CommandException, LoggerException {
        return exec(cmd, true);
    }
    
    public synchronized int reapply(Command cmd) throws CommandException, LoggerException {
        return exec(cmd, false);
    }

    // when we are reapplying, there is no need for logging, of cource...
    protected synchronized int exec(Command cmd, boolean log) throws CommandException, LoggerException {
        int x = cmd.execute(space);

        if (log) {
            logger.logCommand(cmd);
        }
        return x;
    }
    
    // gateway to logger
    public void executeSnapshot() throws LoggerException {
        logger.takeSnapshot(space);
    }
    
    // gateway to logger
    public Space readSnapshot() throws LoggerException {
        return logger.readSnapshot();
    }
    
    // gateway to logger
    public synchronized void reapplyCommandsFromLog() throws CommandException, LoggerException {
        logger.reapplyCommandsFromLog(this);
    }
}

