/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j;


import java.util.*;
import java.io.*;

import org.space4j.indexing.*;


/**
 * The Space where the objects will be stored in memory.
 * 
 * The Space is typically a data structure like a Map used to store the Objects used by your application.
 * 
 * During a snapshot, the whole Space object is serialized to disk.
 * 
 * @author Sergio Oliveira Jr
 */
public interface Space extends Serializable {
    
    /**
     * Gets the Object stored in this Space with this key.
     * 
     * @param key The key to retrieve the Object from the Space.
     * @return The object stored in the Space with this key or null with there is no such object.
     */
    public <T> T get(Object key);

    /**
     * Puts an Object in this Space with this key.
     * 
     * If and Object already exists with this key, the object is replaced by the new one.
     *      
     * @param key The key to store the Object
     * @param obj The object to store
     */
    public void put(Object key, Object obj);
    
    /**
     * Removes an Object from this Space with this key.
     * 
     * @param key
     * @return true if object existed and was removed
     */
    public boolean remove(Object key);
    
    /**
     * Returns an iterator of the underlying collection or map object.
     * 
     * @param key The key to retrieve the Object from the Space.
     * @return A safe iterator of the data structure.
     */
    public <T> Iterator<T> getIterator(Object key);

    /**
     * Checks whehter an object exists with the following key.
     * 
     * @param key The key to check
     * @return true if there is an object
     */
    public boolean check(Object key);
    
    /**
     * Returns an iterator of the keys of the underlying map object.
     * 
     * @param key The key to retrieve the Object from the Space.
     * @return A safe iterator of the keys of the Map.
     */
    public <T> Iterator<T> getKeyIterator(Object key);
     
    /**
     * Returns the IndexManager in this space.
     * 
     * @return The IndexManager in this space.
     */
    public IndexManager getIndexManager();

}
    
