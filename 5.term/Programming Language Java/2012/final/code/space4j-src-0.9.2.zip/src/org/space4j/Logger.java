/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j;


/**
 * An interface defining how a Logger Object should work.
 * A Logger is responsible for logging the commands to disk, taking snapshots of the Space to disk, 
 * recovering snapshots of the Space from disk, and reapplying the logged Commands.
 */
public interface Logger {
    
    /**
     * Log a command to a log file on disk.
     * @param cmd The command to log
     */
    public void logCommand(Command cmd) throws LoggerException;
    
    /**
     * Take a snapshot of the Space to disk. The Space will be serialized and written to disk.
     * @param space The space to be saved.
     */
    public void takeSnapshot(Space space) throws LoggerException;

    /**
     * Take a snapshot of the Space to disk. The Space will be serialized and written to disk.
     * @param space The space to be saved.
     * @param snapnumber The number of the snapshot to be saved.
     */
    public void takeSnapshot(Space space, long snapnumber) throws LoggerException;

    /**
     * Recover the last snapshot from disk and recreate a Space from it.
     * @return A space recovered from the snapshot or null if there were no space to recover in disk.
     */
    public Space readSnapshot() throws LoggerException;
    
    /**
     * Read the last commands from the log and re-apply them to this Space4J.
     * The last commands are the commands after the last snapshot, in other words, those that were not reflected by the last snaphot.
     * OBS: Let's say there is a crash before the system can take a snapshot. The log will be used to reconstruct the space.
     * Actually the rule to initialization is: "Recover the last snapshot and recover the commands after the last snapshot.
     * @param space4j The Space4J that will redo the commands.
     */
    public void reapplyCommandsFromLog(Space4J space4j) throws LoggerException, CommandException;
    
    /**
     * Get the current log number.
     * @return The current log number.
     */
    public long getLogNumber();
    
}
