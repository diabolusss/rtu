/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.implementation;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.space4j.Space;
import org.space4j.indexing.IndexManager;


/**
 * A trivial implementation of Space, in other words, our space just use a Map.
 */
public class SimpleSpace implements Space {
    
    private static final List<Object> EMPTY = new ArrayList<Object>(0);
	
    private Map<Object, Object> map = null;
    
    /** Initializes the SimpleSpace. */
    public SimpleSpace() {
    	
        map = new ConcurrentHashMap<Object, Object>(16, 0.75f, 1); // 1 = one writer / many readers...
        
    }

    /** Initializes the SimpleSpace with a Map. */
    public SimpleSpace(Map<Object, Object> map) {
    	
        this.map = map;
        
    }
    
    public <T> T get(Object key) {
    	
        return (T) map.get(key);
        
    }
    
    public void put(Object key, Object obj) {
    	
        map.put(key, obj);
        
    }
    
    public boolean remove(Object key) {
    	
        return map.remove(key) != null;
    }
    
    public <T> Iterator<T> getIterator(Object key) {
    	
        Object obj = get(key);
        
        if (obj instanceof Collection) {
            
            Collection<T> c = (Collection<T>) obj;
            
            return c.iterator();
            
        } else if (obj instanceof Map) {
            
            Map<Object, T> m = (Map<Object, T>) obj;
            
            return m.values().iterator();
        }
        
        return ((Collection<T>) EMPTY).iterator();
        
    }
    
    public <T> Iterator<T> getKeyIterator(Object key) {
    	
        Object obj = get(key);
        
        if (obj instanceof Map) {
        	
            Map<T, Object> m = (Map<T, Object>) obj;
        	
            return m.keySet().iterator();
        	
        }
        
        return ((Collection<T>) EMPTY).iterator();
    }
    
    public boolean check(Object key) {
    	
        return map.containsKey(key);
    }
    
    public IndexManager getIndexManager() {
    	
        return (IndexManager) get(IndexManager.KEY);
        
    }

}
