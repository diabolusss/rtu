/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.indexing;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


/**
 * A key to be used by the Maps of the IndexManager.
 */
public class Key implements Serializable {
    
    private List<Object> values = null;
    
    /**
     * Creates a new Key.
     */
    public Key() {
        values = new ArrayList<Object>();
    }
    
    public Key(String...args) {
    	
        this();
    	
        for (int i = 0; i < args.length; i++) {
    		
            add(args[i]);
        }
    }
    
    /**
     * Creates a new Compound Key (int + String)
     * @param i An integer
     * @param s An String
     */
    public Key(int i, String s) {
        this();
        add(new Integer(i));
        add(s);
    }

    /**
     * Creates a new Key (int)
     * @param i An integer
     */
    public Key(int i) {
        this();
        add(new Integer(i));
    }

    /**
     * Creates a new Key (String)
     * @param s An String
     */
    public Key(String s) {
        this();
        add(s);
    }
    
    public Key(Object obj) {
        this();
        add(obj);
    }

    public Key(Object...objs) {
        this();
        for (int i = 0; i < objs.length; i++) {
            add(objs[i]);
        }
    }
    
    /**
     * Add a new value for this key.
     * Compound keys have more than one value.
     * @param value The value to be added.
     */
    public void add(Object value) {
        values.add(value);
    }
    
    public int hashCode() {
        Iterator<Object> iter = values.iterator();
        int hash = 0;

        while (iter.hasNext()) {
            Object obj = iter.next();

            if (obj == null) {
                hash = hash * 31 + 1;
            } else {
                hash = hash * 31 + obj.hashCode();
            }
        }
        return hash;
    }
    
    public boolean equals(Object obj) {
        if (!(obj instanceof Key)) {
            return false;
        }
        Key key = (Key) obj;

        if (key.values.size() != this.values.size()) {
            return false;
        }
        
        int x = key.values.size();

        for (int i = 0; i < x; i++) {
            Object key1 = key.values.get(i);
            Object key2 = this.values.get(i);

            if (key1 == null && key2 == null) {
                continue;
            }
            if (key1 == null || key2 == null) {
                return false;
            }
            if (!key1.equals(key2)) {
                return false;
            }
        }
        return true;
    }
    
    public int size() {
    	
        return values.size();
    	
    }
    
    public Object get(int i) {
    	
        return values.get(i);
    }
}
            
