package org.space4j.indexing;

import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;

/**
 * Merge two or more sets into a single collection without doing any kind of copying.
 * 
 * @author sergio.oliveira.jr@gmail.com
 *
 * @param <E>
 */
public class CollectionOfSets<E> implements Collection<E> {
	
	private final Collection<Set<E>> sets;
	
	public CollectionOfSets(Collection<Set<E>> sets) {
		this.sets = sets;
	}
	
	private class CollectionOfSetsIterator<X> implements Iterator<X> {

		private Iterator<X> currentIter = null;
		private final Iterator<Set<X>> mainIter;

		public CollectionOfSetsIterator(Collection<Set<X>> sets) {
			
			mainIter = sets.iterator();
			
			if (mainIter.hasNext()) {
				
				currentIter = mainIter.next().iterator();
				
			} else {
				
				currentIter = null;
			}
		}
		
        public boolean hasNext() {
        	
        	if (currentIter == null) return false;
        	
        	if (currentIter.hasNext()) {
        		
        		return true;
        		
        	} else {
        		
        		if (!mainIter.hasNext()) {

        			currentIter = null;
        			
        			return false;
        			
        		} else {
        			
        			currentIter = mainIter.next().iterator();
        			
        			return hasNext();
        		}
        	}
        }

        public X next() {
        	
        	if (currentIter == null) throw new NoSuchElementException();
        	
        	return currentIter.next();
        }

        public void remove() {

        	if (currentIter == null) throw new NoSuchElementException();
	        
        	currentIter.remove();
        }
	}

    public int size() {
		
		int size = 0;
		
		for(Set<E> s : sets) size += s.size();
		
		return size;
    }

    public boolean isEmpty() {

		for(Set<E> s : sets) if (!s.isEmpty()) return false;
		
		return true;
    }

    public boolean contains(Object o) {

		for(Set<E> s : sets) if (s.contains(o)) return true;
		
		return false;
    }

    public Iterator<E> iterator() {
    	
    	return new CollectionOfSetsIterator<E>(sets);
    }

    public Object[] toArray() {
    	
    	throw new UnsupportedOperationException("This collection is read-only!");
    }

    public <T> T[] toArray(T[] a) {
    	
    	throw new UnsupportedOperationException("This collection is read-only!");    	
    }
	
    public boolean add(E e) {

		throw new UnsupportedOperationException("This collection is read-only!");
	}

    public boolean remove(Object o) {

		throw new UnsupportedOperationException("This collection is read-only!");
	}

    public boolean containsAll(Collection<?> c) {
    	
    	Iterator<?> iter = c.iterator();
    	
    	while(iter.hasNext()) {
    		
    		if (!contains(iter.next())) return false;
    	}
    	
    	return true;
    }

    public boolean addAll(Collection<? extends E> c) {

		throw new UnsupportedOperationException("This collection is read-only!");
	}

    public boolean removeAll(Collection<?> c) {

		throw new UnsupportedOperationException("This collection is read-only!");
	}

    public boolean retainAll(Collection<?> c) {

		throw new UnsupportedOperationException("This collection is read-only!");
	}

    public void clear() {

		throw new UnsupportedOperationException("This collection is read-only!");
    }
}