/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.command;


import java.util.Collection;
import java.util.Map;

import org.space4j.Command;
import org.space4j.CommandException;
import org.space4j.Space;
import org.space4j.indexing.IndexManager;


public class RemoveCmd extends Command {
    
    private final Object target;
    private final Object keyOrValue;
    
    public RemoveCmd(Object target, Object keyOrValue) {
    	
        this.target = target;
        
        this.keyOrValue = keyOrValue;
        
    }
    
    private void indexRemove(Space space, Object value) {
    	
        IndexManager im = space.getIndexManager();
    	
        if (im != null) {
            im.remove(value, target);
        }
    }
    
    public int execute(Space space) throws CommandException {
    	
        Object obj = space.get(target);
    	
        if (obj == null) {
            return 0;
        }
    	
        if (obj instanceof Map) {
    		
            Map<Object, Object> m = (Map<Object, Object>) obj;
    		
            Object value = m.remove(keyOrValue);
    		
            if (value != null) {
                indexRemove(space, value);
            }
    		
            return value != null ? 1 : 0;
    		
        } else if (obj instanceof Collection) {
    	
            Collection<Object> c = (Collection<Object>) obj;
			
            boolean ok = c.remove(keyOrValue);
			
            indexRemove(space, keyOrValue);
			
            return ok ? 1 : 0;
    			
        } else {
			
            throw new CommandException(
                    "Target is not a collection or map: " + target + " ("
                    + obj.getClass().getName() + ")");
        }
    }
}
