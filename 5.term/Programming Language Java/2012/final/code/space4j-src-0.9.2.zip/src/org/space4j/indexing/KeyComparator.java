/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.indexing;


import java.io.Serializable;
import java.util.Comparator;
import java.util.Date;


public class KeyComparator implements Comparator<Key>, Serializable {
	
    private static final long serialVersionUID = 1;
	
    public int compare(Key k1, Key k2) {
		
        int size1 = k1.size();
		
        int size2 = k2.size();
		
        for (int i = 0; i < size1; i++) {
			
            if (i >= size2) {
                break;
            }
			
            Object obj1 = k1.get(i);
			
            Object obj2 = k2.get(i);
			
            if (obj1 instanceof Number && obj2 instanceof Number) {
				
                Number n1 = (Number) obj1;
				
                Number n2 = (Number) obj2;
				
                int x = compareNumbers(n1, n2);
				
                if (x == 0) {
                    continue;
                }
				
                return x;
				
            } else if (obj1 instanceof String && obj2 instanceof String) {
				
                String s1 = (String) obj1;
				
                String s2 = (String) obj2;
				
                int x = compareStrings(s1, s2);
				
                if (x == 0) {
                    continue;
                }
				
                return x;
				
            } else if (obj1 instanceof Date && obj2 instanceof Date) {
				
                Date d1 = (Date) obj1;
				
                Date d2 = (Date) obj2;
				
                int x = compareDates(d1, d2);
				
                if (x == 0) {
                    continue;
                }
				
                return x;
				
            } else {
				
                int x = compareObjects(obj1, obj2);
				
                if (x == 0) {
                    continue;
                }
				
                return x;
				
            }
        }
		
        return 0;
    }
	
    protected int compareStrings(String s1, String s2) {
		
        return s1.compareTo(s2);
		
    }
	
    protected int compareDates(Date d1, Date d2) {
		
        return d1.compareTo(d2);
		
    }
	
    protected int compareNumbers(Number n1, Number n2) {
		
        double d1 = n1.doubleValue();
		
        double d2 = n2.doubleValue();
		
        if (d1 == d2) {
            return 0;
        }
		
        return d1 < d2 ? -1 : 1;
    }
	
    protected int compareObjects(Object obj1, Object obj2) {
		
        return 0;
		
    }
}
