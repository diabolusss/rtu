/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j;


import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;


/**
 * A command representing an update to the Space4J database of objects in RAM.
 * All clients must alter the Space through a Command, so they can be logged and reapplied later.
 */
public abstract class Command implements Serializable {
    
    private long lognumber = -1;
    private long replica_id = 0;
   
    /**
     * This method accesses the Space and its objects to do any modifications it wants.
     * @param space The Space where the objects are stored.
     * @return An int with the number of objects altered by this operation.
     * @throws CommandException If there was an error executing this command.
     */
    public abstract int execute(Space space) throws CommandException;
    
    /**
     * This method will let you replicate your data in a relational database,
     * so you can continue creating your reports and using data data warehousing tools with SQL.
     * Doing this with Space4J and Commands is possible, but not recommended at all.
     * Note that this method is not abstract, therefore it is not required. 
     * It is up to the system to replicate its data in a relational database.
     * <i>Rodolfo de Paula was the first one to raise this issue! Why not have the best of both worlds?</i>
     * @param conn A connection to the database where this command will be executed through SQL.
     * @throws SQLException If there was an error executing the SQL.
     */
    public void executeSQL(Connection conn) throws SQLException {}
    
    /**
     * This method is important when Space4J is replicated.
     * It tells the replicas in what log this command is stored.
     * This will be very important when a replica wants to take a snapshot. It will need to know this number.
     * @return The number of the log where this command is stored.
     */
    public long getLogNumber() {
        return lognumber;   
    }
    
    /**
     * Sets the log number where this command is stored.
     * @param lognumber The log number where this command is stored.
     */
    public void setLogNumber(long lognumber) {
        this.lognumber = lognumber;
    }

    /**
     * This method is important when Space4J is replicated.
     * It tells from which replica this command came from.
     * This will be very important when a replica has to wait for a command to return from the main replica.
     * @return The unique id of the replica.
     */
    public long getReplicaId() {
        return replica_id;
    }

    /**
     * Sets the number of the replica this commands belongs to.
     * @param replica_id The unique id of the replica.
     */
    public void setReplicaId(long replica_id) {
        this.replica_id = replica_id;
    }
}
