/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.implementation;


import org.space4j.*;

import java.util.*;
import java.io.*;


public class SimpleLogger implements Logger {
    
    // each log file will have up to 10k of size
    private static long MAX_LOG_SIZE = 1024 * 10; // 10k 
    
    // 18 should be enough for a very long number
    // Ex: 000000000000000001.log
    private static int NUMBER_OF_DIGITS = 18;
    
    // the main dir of all client dirs
    private static String DIR = "space4j_db";
    
    private static String LOG_PREFIX = ".log";
    private static String SNAPSHOT_PREFIX = ".snap";
    
    private SizedFileOutputStream sfos = null;
    private ObjectOutputStream out = null;
    private long lognumber = 0;
    private String dirname;

    /**
     * Initializes this SimpleLogger.
     * SimpleLogger uses a special directory named space4j_db to store all other directories.
     * Each application (client) has its own subdirectory below this one.
     * You pass the name of this subdirectory through the dirname parameter.
     * @param dirname The dir where to store the files.
     */
    public SimpleLogger(String dirname) { 
        this.dirname = dirname;
        lognumber = getLastLog() + 1;
        
        // check and make DIR..        
        try {
            File dir = new File(DIR);

            if (!dir.exists()) {
                dir.mkdir();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void setDir(String dir) {
    	SimpleLogger.DIR = dir;
    }
    
    public long getLogNumber() {
        return lognumber;
    }
    
    private void openLog() throws IOException {
        File dir = new File(DIR + "/" + dirname);

        if (!dir.exists()) {
            dir.mkdir();
        }
        lognumber = getLastLog() + 1;
        File log = new File(DIR + "/" + dirname,
                getNumberString(lognumber) + LOG_PREFIX);

        sfos = new SizedFileOutputStream(log);
        out = new ObjectOutputStream(sfos);
    }
    
    private void closeLog() throws IOException {
        if (out != null) {
            out.close();
        }
        out = null;
    }
        
    public synchronized void logCommand(Command cmd) throws LoggerException {
        try {
            
            if (out == null || sfos.getSize() >= MAX_LOG_SIZE) {
                closeLog();
                openLog();
            }
        
            // save the log number where this command is stored
            cmd.setLogNumber(getLogNumber());
            
            out.writeObject(cmd);
            out.reset();
            out.flush();
            
        } catch (IOException e) {
            e.printStackTrace();
            throw new LoggerException(e.getMessage());
        }
    }
    
    public void takeSnapshot(Space space) throws LoggerException {
        takeSnapshot(space, lognumber);
    }

    public synchronized void takeSnapshot(Space space, long snapnumber) throws LoggerException {
        try {
            
            closeLog();
            
            File dir = new File(DIR + "/" + dirname);

            if (!dir.exists()) {
                dir.mkdir();
            }
            File file = new File(DIR + "/" + dirname,
                    getNumberString(snapnumber) + SNAPSHOT_PREFIX);
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);

            oos.writeObject(space);
            oos.flush();
            oos.close();
            
        } catch (IOException e) {
            e.printStackTrace();
            throw new LoggerException(e.getMessage());
        }
    }
    
    public synchronized Space readSnapshot() throws LoggerException {
        try {
            
            long lastsnap = getLastSnapshot();

            if (lastsnap == 0) {
                return null;
            }
        
            File file = new File(DIR + "/" + dirname,
                    getNumberString(lastsnap) + SNAPSHOT_PREFIX);
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            Space space = (Space) ois.readObject();

            ois.close();

            return space;
            
        } catch (IOException e) {
            e.printStackTrace();
            throw new LoggerException(e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new LoggerException(e.getMessage());
        }
    }
    
    // If last snapshot is X, than I must apply all command beginning with X + 1.
    public synchronized void reapplyCommandsFromLog(Space4J space4j) throws LoggerException, CommandException {
            
        long lastsnap = getLastSnapshot();
        long start = lastsnap + 1;
        
        File file = new File(DIR + "/" + dirname,
                getNumberString(start) + LOG_PREFIX);
        
        while (file.exists()) {
            
            try {
                
                FileInputStream fis = new FileInputStream(file);
                ObjectInputStream ois = new ObjectInputStream(fis);
            
                try {
                    while (true) {
                        Command cmd = (Command) ois.readObject();

                        space4j.reapply(cmd); // of course, no need to log here
                    }
                } catch (EOFException e) {// normal... no more objects to read...
                } catch (CommandException e) {
                    throw e;
                } catch (IOException e) {
                    e.printStackTrace();
                    throw new LoggerException(e.getMessage());
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                    throw new LoggerException(e.getMessage());
                } finally {
                    try {
                        ois.close();
                    } catch (Exception e) {}
                }
            
                start++;
            
                file = new File(DIR + "/" + dirname,
                        getNumberString(start) + LOG_PREFIX);
            } catch (IOException e) {
                e.printStackTrace();
                throw new LoggerException(e.getMessage());                
            }
        }
    }
    
    // construct a big number with NUMBER_OF_DIGITS digits    
    private String getNumberString(long d) {
        String s = String.valueOf(d);
        int x = NUMBER_OF_DIGITS - s.length();
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < x; i++) {
            sb.append("0");
        }
        sb.append(s);
        
        return sb.toString();
    }
    
    // find the number of the last snapshot in disk
    private long getLastSnapshot() {
        File dir = new File(DIR + "/" + dirname);
        
        File[] files = dir.listFiles(new FileFilter() {
            public boolean accept(File file) {
                String filename = file.getName();

                if (filename.endsWith(SNAPSHOT_PREFIX)) {
                    return true;
                }
                return false;
            }
        });
        
        if (files == null) {
            return 0;
        }
        
        Arrays.sort(files);
        
        if (files.length == 0) {
            return 0;
        } else {
            String filename = files[files.length - 1].getName();

            return Long.parseLong(filename.substring(0, filename.indexOf(".")));
        }
    }
    
    // find the last log file number saved to disk
    private long getLastLog() {
        
        long lastsnap = getLastSnapshot();

        long lastlog = lastsnap + 1;
        
        File file = new File(DIR + "/" + dirname,
                getNumberString(lastlog) + LOG_PREFIX);
        
        while (file.exists()) {
            lastlog++;
            file = new File(DIR + "/" + dirname,
                    getNumberString(lastlog) + LOG_PREFIX);
        }
        
        lastlog--;
        
        return lastlog;
        
    }

    /* A FileOutputStream that keeps track of its size, so we can rotate the log when it is too big. */    
    private class SizedFileOutputStream extends FileOutputStream {
        
        private long size = 0;
        
        public SizedFileOutputStream(File file) throws IOException {
            super(file);
        }
    
        public long getSize() {
            return size;
        }
    
        public void flush() throws IOException {
            super.flush();
            getFD().sync(); // make sure if flushes !!!
        }
    
        public void write(byte[] b) throws IOException {
            super.write(b);
            size += b.length;
        }

        public void write(byte[] b, int off, int len) throws IOException {
            super.write(b, off, len);
            size += len;
        }

        public void write(int b) throws IOException {
            super.write(b);
            size++;
        }
       
    }
        
}    

