/*
 * Space4J http://www.space4j.org/
 * Copyright (C) 2007  Sergio Oliveira Jr. (sergio.oliveira.jr@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.space4j.indexing;


import java.util.Collection;
import java.util.Map;

import org.space4j.Command;
import org.space4j.CommandException;
import org.space4j.Space;


class CreateIndexCmd extends Command {
    
    private Index<?> indx;
    
    public CreateIndexCmd(Index<?> indx) {
        this.indx = indx;
    }
    
    public int execute(Space space) throws CommandException {
    	
        IndexManager im = space.getIndexManager();
        
        if (im == null) {
            throw new CommandException("Cannot find IndexManager!");
        }
        
        if (im.checkIndex(indx.getName())) {
        	
            return 0;
        	
        }
        
        Object source = indx.getSource();
        
        Object obj = space.get(source);
        
        if (obj == null) {
            throw new CommandException("Cannot find source: " + source);
        }
        
        Collection<Object> coll = null;
        
        if (obj instanceof Map) {
        	
            coll = ((Map<Object, Object>) obj).values();
        	
        } else if (obj instanceof Collection) {
        	
            coll = (Collection<Object>) obj;
        }

        im.createIndexImpl(indx, coll);
        
        return 1;
    }
}
        
