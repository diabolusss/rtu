TASM.EXE 	- Compiler (tasm /? to get help)
TLINK.EXE 	- Linker (tlink /? to get help)
AFDPRO.EXE 	- Small and easy to use debugger (afdpro <filename>)
RF.EXE		- Removes TSR programs from memory (rf ? to get help)


