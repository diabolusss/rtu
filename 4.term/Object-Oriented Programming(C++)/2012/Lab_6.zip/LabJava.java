class CoordPoint {
   private final static int DefX = 0;
   private final static int DefY = 0;
   private int X, Y;

   public CoordPoint() {
      X = DefX;
      Y = DefY;
   }
   public CoordPoint(int X, int Y) {
      this.X = X;
      this.Y = Y;
   }

   public int getX() {
      return X;
   }
   public int getY() {
      return Y;
   }

   public void setX(int X) {
      this.X = X;
   }
   public void setY(int Y) {
      this.Y = Y;
   }

   public String toString() {
      return "X:" + X + ", Y:" + Y + ".";
   }
}

public class LabJava {
   public static void main(String[] args) {
      CoordPoint CP1 = new CoordPoint(1, 2), 
                 CP2 = new CoordPoint();

      System.out.println(CP1.toString());
      System.out.println(CP1);
      System.out.println(CP2);

      CP2.setX(3);
      CP2.setY(4);

      System.out.println(CP2);
      System.out.println("\nPress \"Enter\" to finish program... ");

      try {
         System.in.read();
      }
         catch(java.io.IOException e) {
            System.out.println("Input/output exception.");
         }

   }
}