#include <iostream.h>
#include <stdio.h>
#include <string.h>

class MyString {
private:
   char *ps;
   int size,len;

public:
   MyString();
   MyString(int maxLength);
   MyString(char *str);
   ~MyString() { delete ps; }
   void assign(char *str);
   int length() { return len; }
   void print() { cout << ps << endl; }


};

MyString::MyString() {
   ps = new char[256];
   size = 256; len = 0; ps[0] = 0;
}

MyString::MyString(int maxLength) {
	ps = new char[maxLength + 1];
   	size = maxLength + 1; len = 0; ps[0] = 0;
}

MyString::MyString( char *str )
{
	len = strlen( str );
	ps = new char[len+1];
	strcpy( ps, str );
	size = len+1;
}

void MyString::assign(char *str)
{
	strncpy(ps, str, size);	//copy string
	ps[size] = '\0';		//assure terminal 0
	len = strlen(str);		//assign length
}

int main(){

   MyString input("ABCD");
   MyString pwd = input;  // te izpilda kopijas konstruktoru

   cout<<"input=";
   input.print();
   cout<<"pwd=";
   pwd.print();

   input.assign("XYZ"); // izmaina tikai input vertibu!

   cout<<"input=";
   input.print();
   cout<<"pwd=";
   pwd.print();




   getchar();

}

