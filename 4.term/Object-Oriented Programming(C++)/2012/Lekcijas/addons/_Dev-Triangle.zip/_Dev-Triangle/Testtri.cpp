#include <iostream.h>
#include <stdio.h>
#include "triangle.h"

int main()
{
	Triangle t;

 // Malu garumi
	t.a = 3;
	t.b = 4;
	t.c = 5;


	float ta;
	ta = t.area();
	cout 	<< "Area of triangle is " << ta << '\n';
	cout 	<< "Perimeter of triangle is " << t.perimeter() << '\n';


 //
    getchar();
}

