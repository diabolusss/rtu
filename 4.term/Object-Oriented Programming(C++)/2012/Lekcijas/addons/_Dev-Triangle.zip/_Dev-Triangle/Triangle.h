class Triangle {
           public:
	          	int a, b, c;
	            float area();
	            int perimeter();
};

