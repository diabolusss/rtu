#include <math.h>
#include "triangle.h"

float Triangle::area()
{	
	float p; 	
	p = (a + b + c) / 2.0;	// pusperimetrs
	return ( sqrt(p * (p - a) * (p - b) * (p - c)) );
}

int Triangle::perimeter()
{
	return (a + b + c);
}

