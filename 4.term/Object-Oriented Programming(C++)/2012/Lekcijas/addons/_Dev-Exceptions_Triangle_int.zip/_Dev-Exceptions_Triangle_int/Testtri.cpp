#include <iostream.h>
#include <stdio.h>
#include "triangle.h"

int main()
{
  try{
 	Triangle t(100, 5, 70);
	cout 	<< "Area is " <<  t.area() << '\n';
	cout 	<< "Perimeter is " << t.perimeter() << '\n';
 }

 catch (int e)
 {
       cout << "Invalid sides! "<< e;
 }
  catch (...)
 {
       cout << "Unknown exception";
 }
//
    getchar();
}

