#include <iostream.h>
#include <stdio.h>

#ifndef _Figure
#define _Figure
#include "Figure.h"
#endif

#ifndef _Rectangle
#define _Rectangle
#include "Rectangle.h"
#endif

#ifndef _RectangleFilled
#define _RectangleFilled
#include "RectangleFilled.h"
#endif

int main()
{ 
  { cout << "Begin \n";        // begin internal block
	RectangleFilled *prf;                                 getchar();

	prf = new RectangleFilled;                            getchar();

	Rectangle r;                                          getchar();

	r.setDim(1,1,10,20);
	cout << "\nArea of rectangle is "<< r.area() << "\n\n";   getchar();
    
    prf->setDim(0, 0, 3, 5);
	prf->setColor(15);
	cout << "\nArea of filled rectangle is "<< prf->area() << "\n\n";  getchar();

    delete prf;                                            getchar();

  } cout << "End \n";         // end of internal block
    
    
    getchar();
}
