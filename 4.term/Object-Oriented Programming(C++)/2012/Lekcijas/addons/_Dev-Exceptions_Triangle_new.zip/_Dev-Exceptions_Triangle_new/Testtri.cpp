#include <iostream.h>
#include <stdio.h>
#include "triangle.h"

int main()
{
 try{

	Triangle t(40, 50, 30);
	cout 	<< "Area is " <<  t.area() << '\n';
	cout 	<< "Perimeter is " << t.perimeter() << '\n';

    Triangle f(4, 15, 3);
	cout 	<< "Area is " <<  f.area() << '\n';
	cout 	<< "Perimeter is " << f.perimeter() << '\n';
 }
 catch (SidesException*) {
  cout << "Invalid sides!" << endl;
 }
 catch (...) {
  cout << "Unknown exception!" << endl;
 }




//
    getchar();
}

