#include <math.h>
#include "triangle.h"

Triangle::Triangle(int x,int y,int z)
{
 if (x+y<=z || x+z<=y || y+z<=x)
    throw new SidesException;
 a = x;
 b = y;
 c = z;
}

float Triangle::area()
{	
	float p; 	
	p = perimeter() / 2.0;
	return ( sqrt(p * (p - a) * (p - b) * (p - c)) );
}

int Triangle::perimeter()
{
	return (a + b + c);
}

