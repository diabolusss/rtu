class Triangle {
private:
        int a, b, c;
public:
       Triangle() { a = b = c = 0; }
       Triangle(int, int, int);

       float area();
       int perimeter();
};

class SidesException{};
