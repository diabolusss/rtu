#include <iostream.h>
#include <stdio.h>

class A
{  private: int a;
   public:
   A()
   {  a = 0;
      cout << "Default constructor" << endl;
   }
   A(int v)
   {  a = v;
      cout << "INT constructor" << endl;
   }
   A(const A& aa)
   {  a = aa.a;
      cout << "Copy constructor" << endl;
   }
   ~A()
   {  cout << "Destructor" << endl;
   }
   int getA() { return a; }
};

int main()
{
   cout << "main begin" << endl;
   int i = 1;                            getchar(); cout<<"A x, y[4], *pa;"<<endl;
   A x, y[4], *pa;
                                         getchar(); cout<<"A w = x;"<<endl;
   A w = x;
                                         getchar(); cout<<"A v = y[2];"<<endl;
   A v = y[2];
                                         getchar(); cout<<"A z = 2;"<<endl;
   A z = 2;
                                         getchar(); cout<<"pa = new A;"<<endl;
   pa = new A;
                                         getchar(); cout<<"pa =  &z;"<<endl;
   pa =  &z;
                                         getchar(); cout<<"*pa =  i;"<<endl;
   *pa =  i;
                                         getchar(); cout<<"delete pa;"<<endl;
   delete pa;
                                         getchar();
   cout << "main end" << endl;
                                         getchar();
}
