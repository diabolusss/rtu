#include <iostream.h>
#include <stdio.h>

#include "Alpha.h"

Alpha a; // global object a

int main()
{ 
    cout << "Begin main block\n"; 

  Alpha b; // object b
        b.setN(2);
        
  Alpha *pa; // pointer pa
    
  { cout << "Begin nested block\n";  
         static Alpha c;   c.setN(3); // object c
         Alpha d;          d.setN(4); // object d
         cout << "Just before end of the nested block\n"; 
  } 
  cout << "Nested block ended\n"; 
  pa = new Alpha;  
    
    cout << "Just before end of the main block\n"; 
    
    //getchar();
} // destructor for b, c and global object a
