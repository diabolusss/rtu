class Alpha{
private:
	int n;
public:
	Alpha() { n = 0; cout<< "***** constructor Alpha() \n"; }
	~Alpha(){ cout<< "***** destructor ~Alpha() \n"; }
	void setN( int n ) { if (n>=0) this->n = n; }
	int getN() { return n; }
};
