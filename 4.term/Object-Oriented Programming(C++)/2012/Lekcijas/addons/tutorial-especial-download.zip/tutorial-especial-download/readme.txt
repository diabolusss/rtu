         --------------------------------------
               The cplusplus.com tutorial
                "C++ Language Tutorial"
                June 2000 // April 2001
             (c) The C++ Resources Network
                   www.cplusplus.com
         --------------------------------------

The C++ Language Tutorial is a self-explanatory tutorial that
describes the C++ language from its basics.



CONTENT

This package contains exclusively the C++ language tutorial
and some papers linked from it. Any other resource like
function references mentioned in the tutorial are not
included in this distribution although they are available at the
C++ Resources Network site:
	http://www.cplusplus.com




REQUIREMENTS

A HTML browser, like Netscape Navigator or Internet Explorer.
Recommended: A C++ compiler to compile the example programs.



GETTING STARTED

The main directory contains a file called "index.html", open
this file with your html browser to begin the tutorial.



AUTHORING

This tutorial has been written by Juan Soulie for The C++
Resources Network - cplusplus.com .

Do not redistribute the content of this package without
prior permission from the owner of the copyright.

In case you find any errors in this tutorial please
contact the author:

	Juan Soulie <jsoulie@cplusplus.com>
