/*+==================================+*/
/*| * Waspmote_Xbee.cpp               */
/*| *                                 */
/*| * Created: 4/9/2013 11:27:12 AM   */
/*| * Author: GG                      */
/*+==================================+*/

#include "WaspXBee802.h"
#include "Functions.h"

int main()
{
	init();
	vSetUp();

	while(1)
	{
		vLoop();
	}
}
