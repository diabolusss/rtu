/*+==================================+*/
/*| * Functions.h                     */
/*| *                                 */
/*| * Created: 4/9/2013 11:27:12 AM   */
/*| * Author: GG                      */
/*+==================================+*/


#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_

#include "WaspXBee802.h"
#include "WaspXBeeCore.h"
#include "WaspSensorGas.h"
#include <stdio.h>
#include "Global.h"
#include "WaspUtils.h"
#include "WaspPWR.h"
#include "WaspRTC.h"

//char * DEST_MAC_ADDRESS = "0013A20040763BA6";
//char * MY_MAC_ADDRESS   = "0013A20040763BA5";

#define R_OK  0
#define R_NOK 1



#define MAX_DATA_TO_SEND      100
#define MAX_DATA_FOR_MESSAGE  50
#define SENSOR_READ_COUNT     3

typedef enum ENUM_COMMANDS
{
	SNR_FIRST,
	SNR_HUMIDITY_ON,
	SNR_HUMIDITY_OFF,
	SNR_TEMP_ON,
	SNR_TEMP_OFF,
	SNR_CO2_ON,
	SNR_CO2_OFF,
	SNR_LAST
};

void vSetUp(void);
void vLoop(void);
float fGetTemp(char * pcMessage);
float fGetCO2(char * pcMessage);
float fGetHumidity(char * pcMessage);
uint8_t ui8_GetBatteryStats(char * pcMessage);
void vSendData(char * pcData);
uint8_t ui8_ReceiveData(char * pcData);
void vParseData(char * pcData);
void vDeepSleep(uint8_t ui8_Sek);

#endif /* FUNCTIONS_H_ */