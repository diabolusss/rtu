/************************************************************ 
DO NOT MODIFY 
Automatically Generated On -- 16-11- by pre-genfiles.bat 
*************************************************************/ 
const char* HEADER_MSG = "Waspmote_Xbee-Debug -- 16-11-"; 
