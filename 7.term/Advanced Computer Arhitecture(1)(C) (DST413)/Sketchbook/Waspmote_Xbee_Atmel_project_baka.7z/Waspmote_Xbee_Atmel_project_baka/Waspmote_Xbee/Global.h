/*+==================================+*/
/*| * Global.h                        */
/*| *                                 */
/*| * Created: 4/9/2013 11:27:12 AM   */
/*| * Author: GG                      */
/*+==================================+*/


#ifndef GLOBAL_H_
#define GLOBAL_H_

#define TYPE_TEMP    1
#define TYPE_HUMYDTY 2
#define TYPE_DUST    3
#define TYPE_CO2     4

//#define _USB   1 // if define _USB Xbee will not be used
#define _DEBUG 0 // if define _DEBUG adittional data will be printed to USB

#endif /* GLOBAL_H_ */