/*+==================================+*/
/*| * Functions.cpp                   */
/*| *                                 */
/*| * Created: 4/9/2013 11:27:12 AM   */
/*| * Author: GG                      */
/*+==================================+*/


#include "Functions.h"


/*+==================================+*/
/*| Function to set up scheme        |*/
/*+==================================+*/
void vSetUp(void)
{
	xbee802.init(XBEE_802_15_4,FREQ2_4G,NORMAL);
	xbee802.ON();
	
	SensorGas.setBoardMode(SENS_ON);
	
	USB.begin();
	delay(50);
	
	XBee.begin();
	delay(50);
	
	RTC.ON();
	
	SensorGas.configureSensor(SENS_TEMPERATURE, 1);
	SensorGas.setSensorMode(SENS_ON, SENS_TEMPERATURE);
	delay(50);
	
	SensorGas.configureSensor(SENS_CO2, 1);
	SensorGas.setSensorMode(SENS_ON, SENS_CO2);
	delay(50);
	
	SensorGas.configureSensor(SENS_HUMIDITY, 1);
	SensorGas.setSensorMode(SENS_ON, SENS_HUMIDITY);
	delay(50);
}

/*+==================================+*/
/*| Main loop Function               |*/
/*+==================================+*/
void vLoop(void)
{
	char pcData[MAX_DATA_TO_SEND] = {0};
	
	fGetTemp(pcData);
	strcat(pcData, ";");
	
	fGetCO2(&pcData[strlen(pcData)]);
	strcat(pcData, ";");
	
	fGetHumidity(&pcData[strlen(pcData)]);
	strcat(pcData, ";");
	
	ui8_GetBatteryStats(&pcData[strlen(pcData)]);
	strcat(pcData, ";");

#ifdef _USB
	USB.println(pcData);
#else
	vSendData(pcData);
#endif
	
	//memset(pcData, 0, sizeof(pcData)); // not implemented
//#ifndef _USB
	//if(ui8_ReceiveData(pcData) == R_OK)
	//{
		//vParseData(pcData);
	//}
//#endif
#ifdef _DEBUG
	USB.println("Delay for 1,5 sek");
#endif
	delay(1500);
	//USB.println("Sleep for 10 sek...");
	//vDeepSleep(10);
}

/*+=========================================================+*/
/*| Function to get temp value from gas board               |*/
/*+=========================================================+*/
float fGetTemp(char * pcMessage)
{
	float temperatureVal = 0;
	float fTempInC = 0;
	
	sprintf(pcMessage, "Temp:");
	temperatureVal = SensorGas.readValue(SENS_TEMPERATURE);  // 0.4V = 0C ->  2.4V = 100C  => 2V uz 100C = 0.025
	
#ifdef _DEBUG
	XBee.println("Received Temp:");
	XBee.printFloat(temperatureVal, 6);
	XBee.println("V");
#endif
	
	fTempInC = (temperatureVal  - 0.52) * 100;

#ifdef _DEBUG
	XBee.println("Converted Temp:");
	XBee.printFloat(fTempInC, 2);
	XBee.println("C");
#endif

	Utils.float2String(fTempInC, &pcMessage[strlen(pcMessage)], 2);
	
	return fTempInC;
}

/*+=========================================================+*/
/*| Function to get CO2 value from gas board                |*/
/*+=========================================================+*/
float fGetCO2(char * pcMessage)
{
	float fCo2Value = 0;
	float fppmCo2 = 0;

	//for(int i = 0; i < SENSOR_READ_COUNT; i++)
	//{
		fCo2Value = SensorGas.readValue(SENS_CO2); // 0V = 500ppm - 0.9V = 10 000 ppm => 0.9V uz 9 500 ppm 0.0000946
	
#ifdef _DEBUG
	XBee.println("Received CO2:");
	XBee.printFloat(fCo2Value, 6);
	XBee.println("V");
#endif
	
	fppmCo2 = fCo2Value / 0.0000946;
	
#ifdef _DEBUG
	XBee.println("Converted:");
	XBee.printFloat(fppmCo2, 0);
	XBee.println("PPM");
#endif
	
	sprintf(pcMessage, "CO2:");
	Utils.float2String(fppmCo2, &pcMessage[strlen(pcMessage)], 0);
	
	return fppmCo2;
}

/*+=========================================================+*/
/*| Function to get Humidity value from gas board           |*/
/*+=========================================================+*/
float fGetHumidity(char * pcMessage)
{
	float fHumidityValue = 0;
	float fHmdtityPercents = 0;
	
	for(int i = 0; i < SENSOR_READ_COUNT; i++)
	{
		fHumidityValue = SensorGas.readValue(SENS_HUMIDITY); // 0.48 -> 2.34V. => 0.0186 = 1%
		
#ifdef _DEBUG
		XBee.println("Received Humidity:");
		XBee.printFloat(fHumidityValue, 6);
		XBee.println("V");
#endif
		fHmdtityPercents += (fHumidityValue - 0.81 ) / 0.031;
	}
	
	fHmdtityPercents = fHmdtityPercents / SENSOR_READ_COUNT;
	
#ifdef _DEBUG
	XBee.println("Converted:");
	XBee.printFloat(fHmdtityPercents, 0);
	XBee.println("\%");
#endif
	sprintf(pcMessage, "Hmdty:");
	Utils.float2String(fHmdtityPercents, &pcMessage[strlen(pcMessage)], 0);
	
	return fHmdtityPercents;
}

/*+=========================================================+*/
/*| Function to get Battery status                          |*/
/*+=========================================================+*/
uint8_t ui8_GetBatteryStats(char * pcMessage)
{
	uint8_t ui8_BatteryStats = 0;
	ui8_BatteryStats = PWR.getBatteryLevel();
	sprintf(pcMessage, "Bat: %u", ui8_BatteryStats);
	return ui8_BatteryStats;
}
/*+=========================================================+*/
/*| Function to send data with Xbee                         |*/
/*+=========================================================+*/
void vSendData(char * pcData)
{
	// Set params to send
	XBee.println("Sending");
	packetXBee * paq_sent;
	
	paq_sent = (packetXBee*) calloc(1,sizeof(packetXBee));
	paq_sent->mode = UNICAST; // sending mode
	paq_sent->MY_known = 0;
	paq_sent->packetID = 0x52;
	paq_sent->opt = 0;
	xbee802.hops = 0;
	xbee802.setOriginParams(paq_sent, "5678", MY_TYPE);
	xbee802.setDestinationParams(paq_sent, "0013A20040763BC4", pcData, MAC_TYPE, DATA_ABSOLUTE);
	xbee802.sendXBee(paq_sent); // sending pocket

	free(paq_sent); // free
	paq_sent = NULL;
}

/*+=========================================================+*/
/*| Function to receive data with Xbee                      |*/
/*+=========================================================+*/
uint8_t ui8_ReceiveData(char * pcData)
{
	uint8_t ui8_RetVal = R_NOK;
	long lprevious = 0;
	
	lprevious = millis();

	while(((millis() - lprevious) < 20000) && (ui8_RetVal != R_OK))
	{
		XBee.println("Receiving");
		if(XBee.available())
		{
			xbee802.treatData();
			if(!xbee802.error_RX)
			{
				ui8_RetVal = R_OK;
			}
			break; // failed return R_NOK;
		}
	}
	return ui8_RetVal;
}

/*+=========================================================+*/
/*| Function to parse received data                         |*/
/*+=========================================================+*/
void vParseData(char * pcData)
{
	int g = 0;
	
	while(xbee802.pos>0)
	{
#ifdef _DEBUG
		XBee.print("Network Address Source: ");
		XBee.print(xbee802.packet_finished[xbee802.pos-1]->naS[0],HEX);
		XBee.print(xbee802.packet_finished[xbee802.pos-1]->naS[1],HEX);
		XBee.println("");
		XBee.print("MAC Address Source: ");
		for(int b=0;b<4;b++)
		{
			XBee.print(xbee802.packet_finished[xbee802.pos-1]->macSH[b],HEX);
		}
		for(int c=0;c<4;c++)
		{
			XBee.print(xbee802.packet_finished[xbee802.pos-1]->macSL[c],HEX);
		}
		XBee.println("");
		XBee.print("Network Address Origin: ");
		XBee.print(xbee802.packet_finished[xbee802.pos-1]->naO[0],HEX);
		XBee.print(xbee802.packet_finished[xbee802.pos-1]->naO[1],HEX);
		XBee.println("");
		XBee.print("MAC Address Origin: ");
		for(int d=0;d<4;d++)
		{
			XBee.print(xbee802.packet_finished[xbee802.pos-1]->macOH[d],HEX);
		}
		for(int e=0;e<4;e++)
		{
			XBee.print(xbee802.packet_finished[xbee802.pos-1]->macOL[e],HEX);
		}
		XBee.println("");
		XBee.print("RSSI: ");
		XBee.print(xbee802.packet_finished[xbee802.pos-1]->RSSI,HEX);
		XBee.println("");
		XBee.print("16B(0) or 64B(1): ");
		XBee.print(xbee802.packet_finished[xbee802.pos-1]->mode,HEX);
		XBee.println("");

		XBee.print("PacketID: ");
		XBee.print(xbee802.packet_finished[xbee802.pos-1]->packetID,HEX);
		XBee.println("");
		XBee.print("Type Source ID: ");
		XBee.print(xbee802.packet_finished[xbee802.pos-1]->typeSourceID,HEX);
		XBee.println("");
		XBee.print("Network Identifier Origin: ");
		while( xbee802.packet_finished[xbee802.pos-1]->niO[g]!='#' )
		{
			XBee.print(xbee802.packet_finished[xbee802.pos-1]->niO[g],BYTE);
			g++;
		}
		g = 0;
		XBee.println("");
#endif
		XBee.print("Data: ");
		for(int f = 0; f < (xbee802.packet_finished[xbee802.pos-1]->data_length); f++)
		{
			XBee.print(xbee802.packet_finished[xbee802.pos-1]->data[f],BYTE);
		}
		
		free(xbee802.packet_finished[xbee802.pos-1]);
		xbee802.packet_finished[xbee802.pos-1]=NULL;
		xbee802.pos--;
	}
}

/*+=========================================================+*/
/*| Function to put board in sleep mode                     |*/
/*+=========================================================+*/
void vDeepSleep(uint8_t ui8_Sek)
{
	char pcTimeTo[] = {"00:00:00:00"};
		
	if(ui8_Sek >= 100)
		ui8_Sek = 99;
		
	sprintf(&pcTimeTo[9], "%u", ui8_Sek);
#ifdef _DEBUG
	XBee.println(pcTimeTo);
#endif
	PWR.deepSleep(pcTimeTo, RTC_OFFSET, RTC_ALM1_MODE2, ALL_OFF);
}

/*+=========================================================+*/
/*| Function to process all ENUM_COMMANDS commands          |*/
/*+=========================================================+*/
void vProcessCommand(ENUM_COMMANDS SNR_COMMANDS)
{
	switch (SNR_COMMANDS)
	{
		case SNR_CO2_ON:
		break;
		
		case SNR_CO2_OFF:
		break;
		
		case SNR_HUMIDITY_ON:
		break;
		
		case SNR_HUMIDITY_OFF:
		break;
		
		case SNR_TEMP_ON:
		break;
		
		case SNR_TEMP_OFF:
		break;
		
		default:
		break;
	}
}