#include <stdio.h>

int main(int argc, char** argv) {
  printf("\r\nHello world!\r\n");
  return 0;
}
