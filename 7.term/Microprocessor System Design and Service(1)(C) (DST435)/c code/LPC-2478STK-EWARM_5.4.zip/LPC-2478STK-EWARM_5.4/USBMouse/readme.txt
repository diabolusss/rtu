########################################################################
#
#                           USBMouse.eww
#
#
########################################################################

DESCRIPTION
===========
   This example project should be used only with IAR Embedded Workbench for ARM
  It implements USB HID mouse. When the host install the needed driver the
  mouse's cursor begin moved depending of slope of the board.

COMPATIBILITY
=============

   The example project is compatible with Olimex LPC-2478-STK evaluation board.
  By default, the project is configured to use the J-Link JTAG interface.

CONFIGURATION
=============

   After power-up the controller get clock from internal RC oscillator that
  is unstable and may fail with J-Link auto detect, therefore adaptive clocking
  should always be used. The adaptive clock can be select from menu:
  Project->Options..., section Debugger->J-Link/J-Trace  JTAG Speed - Adaptive.

  Make sure that the following jumpers are correctly configured

  Jumpers:
   EXT/JLINK  - depending of power source
   ISP_E      - unfilled
   RST_E      - unfilled
   BDS_E      - unfilled
   C/SC       - SC

GETTING STARTED
===============

  1) Start the IAR Embedded Workbench for ARM.

  2) Select File->Open->Workspace...
     Open USBMouse.eww workspace:

  3) Run the program.

  4) Use a USB cable to connect the evaluation board to your PC. The first
     time a USB device is connected to your computer, Windows will
     automatically load the proper device driver. In this case, the USB
     HID mouse device driver will be loaded.
