/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2008
 *
 *    File name   : loudness.h
 *    Description : Loudness picture include file
 *
 *    History :
 *    1. Date        : 11, Agust 2008
 *       Author      : Stanimir Bonev
 *       Description : Create
 *
 *    $Revision: 30870 $
 **************************************************************************/
#include "drv_glcd.h"

#ifndef __LOUDNESS_H
#define __LOUDNESS_H

extern Bmp_t LoudnessPic;

#endif // __LOUDNESS_H
