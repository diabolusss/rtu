/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2008
 *
 *    File name   : wide_stereo.h
 *    Description : Wide stereo picture include file
 *
 *    History :
 *    1. Date        : 11, Agust 2008
 *       Author      : Stanimir Bonev
 *       Description : Create
 *
 *    $Revision: 30870 $
 **************************************************************************/
#include "drv_glcd.h"

#ifndef __WIDE_STEREO_H
#define __WIDE_STEREO_H

extern Bmp_t WideStereoPic;

#endif // __WIDE_STEREO_H
