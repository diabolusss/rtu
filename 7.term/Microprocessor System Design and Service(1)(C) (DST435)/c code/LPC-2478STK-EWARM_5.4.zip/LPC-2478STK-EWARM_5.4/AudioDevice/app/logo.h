/*************************************************************************
*
*    Used with ICCARM and AARM.
*
*    (c) Copyright IAR Systems 2009
*
*    File name   : logo.h
*    Description : logo picture header file
*
*    History :
*    1. Date        : 11-Oct-2009
*       Author      : Stoyan Choynev
*       Description : made from logo.bmp with MATLAB
*
*    $Revision: $
**************************************************************************/
#include "drv_glcd.h"
#ifndef __LOGO_H
#define __LOGO_H

extern Bmp_t logoPic;

#endif /* __LOGO_H*/
