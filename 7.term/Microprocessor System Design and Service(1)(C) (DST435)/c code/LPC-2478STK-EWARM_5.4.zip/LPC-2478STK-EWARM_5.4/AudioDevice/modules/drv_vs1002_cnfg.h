/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2006
 *
 *    File name   : drv_vs1002_cnfg.h
 *    Description : VS1002 Driver configuration file
 *
 *    History :
 *    1. Date        : October 10, 2006
 *       Author      : Stanimir Bonev
 *       Description : Create
 *
 *    $Revision: 30870 $
 **************************************************************************/

#ifndef  __DRV_VS1002_CNFG_H
#define  __DRV_VS1002_CNFG_H

#define VS1002_STATUS_VERBOSE   1
#define VS1002_INIT_CLK_FREQ    2000000 // [Hz]
#define VS1002_CLK_FREQ         4000000 // [Hz]
#define VS1002_PLUS_V_ENA       0

#endif  /* __DRV_VS1002_CNFG_H */
