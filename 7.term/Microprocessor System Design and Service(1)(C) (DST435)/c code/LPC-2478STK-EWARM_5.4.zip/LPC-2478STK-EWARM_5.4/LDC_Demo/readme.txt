########################################################################
#
#                           LCD_Demo.eww
#
#
########################################################################

DESCRIPTION
===========
  This example project should be used only with IAR Embedded Workbench for ARM
 It shows basic use of I/O, timer, interrupt and LCD controllers.
 Onlimex logos appear on the LCD and the LCD hardware cursor moves as the board
 moves(the acceleration sensor is used).

COMPATIBILITY
=============

   The example project is compatible with Olimex LPC-2478-STK
  evaluation board. By default, the project is configured to use the
  J-Link JTAG interface.

CONFIGURATION
=============
   After power-up the controller get clock from internal RC oscillator that
  is unstable and may fail with J-Link auto detect, therefore adaptive clocking
  should always be used. The adaptive clock can be select from menu:
   Project->Options..., section Debugger->J-Link/J-Trace  JTAG Speed - Adaptive.

   Make sure that the following jumpers are correctly configured on the
  IAR LPC-2478-SK evaluation board:

  EXT/JLINK  - depending of power source
  ISP_E      - unfilled
  RST_E      - unfilled
  BDS_E      - unfilled
  C/SC       - SC

  The AudioDevice application is downloaded to the iFlash or SDRAM memory.

GETTING STARTED
===============

  1) Start the IAR Embedded Workbench for ARM.

  2) Select File->Open->Workspace...
     Open LCD_Demo.eww workspace:

  3) Run the program.

