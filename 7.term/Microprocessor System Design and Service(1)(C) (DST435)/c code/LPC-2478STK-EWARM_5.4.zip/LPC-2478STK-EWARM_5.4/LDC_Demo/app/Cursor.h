//Cursor 64x64 pixels
#define CURSOR_H_SIZE 64
#define CURSOR_V_SIZE 64
//
#define CIRCLE_R  18

extern const unsigned char Cursor[(CURSOR_H_SIZE/4)*CURSOR_H_SIZE];
