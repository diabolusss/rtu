//Cursor 64x64 pixels
#define CURSOR_H_SIZE 32
#define CURSOR_V_SIZE 32
#include "arm_comm.h"
extern const unsigned char Cursor[(CURSOR_H_SIZE/4)*CURSOR_H_SIZE];
