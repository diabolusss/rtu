########################################################################
#
#                           USB_HostDemo.eww
#
########################################################################

DESCRIPTION
===========
 This example project should be used only with IAR Embedded Workbench for ARM
 It shows basic use of I/O, timer, interrupt and LCD controllers and 
 USB Host Masstorage class framework.

  This example demonstrates how to access the files on "USB Flash drive" 
 connected to USB Host port on Olimex LPC-2478-STK board.
 
COMPATIBILITY
=============

   The USB_HostDemo project is compatible with Olimex LPC-2478-STK evaluationboard.
  By default, the project is configured to use the J-Link JTAG interface.

CONFIGURATION
=============

   After power-up the controller get clock from internal RC oscillator that
  is unstable and may fail with J-Link auto detect, therefore adaptive clocking
  should always be used. The adaptive clock can be select from menu:
  Project->Options..., section Debugger->J-Link/J-Trace  JTAG Speed - Adaptive.
  
  Jumpers:
    EXT/JLINK  - depending of power source
    ISP_E      - unfilled
    RST_E      - unfilled
    BDS_E      - unfilled
    C/SC       - SC
  
GETTING STARTED
===============

  1) Start the IAR Embedded Workbench for ARM.

  2) Select File->Open->Workspace...
     Open USB_HostDemo.eww workspace:

  3) Run the program.
  
  4) Connect a USB flash drive at USB host port. The flash drive should be FAT16 or
     FAT32 formatted and MSREAD.TXT must be present on the device (usb flash drive).
     
     The copy of the file MSREAD.TXT will be created on the USB flash drive.
