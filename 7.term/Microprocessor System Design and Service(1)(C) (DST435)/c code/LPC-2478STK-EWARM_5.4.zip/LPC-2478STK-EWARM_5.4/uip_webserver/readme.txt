########################################################################
#
#                           uip_webserver.eww
#
#
########################################################################

DESCRIPTION
===========
 This example project should be used only with IAR Embedded Workbench for ARM
 This demo shows a web server  application  running on the top of the uIP 1.0 
 TCP-IP stack.

COMPATIBILITY
=============

   The example project is compatible with Olimex LPC-2478-STK
  evaluation board. By default, the project is configured to use the
  J-Link JTAG interface.

   The default IP address is:
    192.168.0.100 (set in main.c main subroutine)
   The physical MAC address is (defined in uipopt.h):
    00-ff-ff-ff-ff-ff

CONFIGURATION
=============

   After power-up the controller get clock from internal RC oscillator that
  is unstable and may fail with J-Link auto detect, therefore adaptive clocking
  should always be used. The adaptive clock can be select from menu:
  Project->Options..., section Debugger->J-Link/J-Trace  JTAG Speed - Adaptive.

   Make sure that the following jumpers are correctly configured

  Jumpers:
    EXT/JLINK  - depending of power source
    ISP_E      - unfilled
    RST_E      - unfilled
    BDS_E      - unfilled
    C/SC       - SC

GETTING STARTED
===============

  1) Start the IAR Embedded Workbench for ARM.

  2) Select File->Open->Workspace...
     Open uip_webserver.eww workspace:

  3) Run the program.

  4) Connect cable between PC LAN Card or Hub and Olimex LPC-2478-STK board.
     Start web browser and type 192.168.0.100 in address field of the browser.


